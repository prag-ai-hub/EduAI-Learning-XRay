"use client";

import { FormEvent, ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

type Role = "Teacher" | "Principal" | "School admin" | "Platform admin";
type TeacherModule = "Home" | "Work" | "Review" | "X-Ray" | "Interventions" | "Students" | "Resources" | "Achievements" | "Reports" | "Settings";
type AdminModule = "Overview" | "Users" | "Schools & Classes" | "Students" | "Academic years" | "Branding & Privacy" | "Schools" | "Analytics" | "AI Configuration" | "Feature flags" | "System health" | "Audit" | "Reports";
type Stage = "draft" | "uploaded" | "setup" | "grading" | "review" | "approved" | "xray" | "intervention" | "followup" | "published";
type Gap = {concept:string; mastery:number;finding?:string;misconception?:string;evidence?:string;rework?:string;severity?:"priority"|"developing"|"secure"};
type GradeResult = {fileId:string; studentName:string; questionPaperFileId?:string; questionPaperName?:string; score:number; maxMarks:number; gaps:Gap[]; date:string; feedback?:string; ocrText?:string;evidenceFingerprint?:string;reanalysisReason?:string};
type Assessment = {
  id:string; title:string; type:string; grade:string; section:string; subject:string;
  maxMarks:number; date:string; stage:Stage; files:UploadFile[]; questions:number;
  reviewed:number; totalReviews:number; quality:number; published:boolean; version:number; gradedFileIds?:string[]; lastGradedFileId?:string;
  gradeResults?:Record<string,GradeResult>; answerKey?:string; rubric?:string;
};
type DocumentRole = "Question paper"|"Marking scheme"|"Model answer"|"Ungraded answer sheet"|"Teacher-graded answer sheet"|"Supporting reference";
type UploadFile = {id:string;name:string;type:string;size:number;progress:number;status:string;preview?:string;documentRole?:DocumentRole};
type User = {id:string;name:string;email:string;role:string;school:string;phone:string;status:"Active"|"Inactive"|"Invited"};
type DemoProfile = {id:string;name:string;email:string;role:Role;school:string;label:string};
type Intervention = {id:string;assessmentId:string;concept:string;format:string;duration:string;status:string;followup:string;followupRecorded?:boolean;followupEvidence?:{studentsCompleted:number;avgMastery:number;outcome:string;note:string}};
type CognitiveLevel = "recall" | "application" | "analysis";
type WorksheetContent = {
  mcqQuestions:{question:string;options:string[];correctIndex:number;cognitiveLevel:CognitiveLevel;concept?:string}[];
  subjectiveQuestions:{question:string;modelAnswer:string;cognitiveLevel:CognitiveLevel;concept?:string}[];
};
type Worksheet = {id:string;title:string;type:string;status:string;template?:string;concept?:string;concepts?:string[];subject?:string;grade?:string;assessmentId?:string;mcq?:number;subjective?:number;difficulty?:string;answerSheets?:number;gradedSheets?:number;content?:WorksheetContent;guide?:any;studentName?:string};
type ApiLogEntry = {provider:"mistral"|"openai";ms:number;ok:boolean;ts:number};
type DemoState = {assessments:Assessment[];users:User[];interventions:Intervention[];classes:string[];schools:string[];students:{id:string;name:string;roll:string;className:string;status:string}[];resources:Worksheet[];academicYears:string[];events:string[];apiLog:ApiLogEntry[]};
type ClassSubjectOption = {key:string;classKey:string;grade:string;section:string;subject:string;studentStrength:number};
const DOCUMENT_ACCEPT=".pdf,.jpg,.jpeg,.png,.heic,.docx,.odt,.md,.markdown,.txt,.rtf,.html,.htm,.xml,.json,.yaml,.yml,.csv,.tsv,.xlsx,.xls,text/*";
const DOCUMENT_EXTENSIONS=new Set(["pdf","jpg","jpeg","png","heic","docx","odt","md","markdown","txt","rtf","html","htm","xml","json","yaml","yml","csv","tsv","xlsx","xls"]);
function supportsDocumentUpload(file:File){return file.type.startsWith("text/")||DOCUMENT_EXTENSIONS.has(file.name.toLowerCase().split(".").pop()||"")}

const initialState:DemoState = {
  assessments:[
    {id:"a1",title:"Fractions checkpoint",type:"Quiz",grade:"6",section:"A",subject:"Mathematics",maxMarks:20,date:"2026-07-21",stage:"review",files:[{id:"f0",name:"Grade6A_Fractions_QuestionPaper.pdf",type:"application/pdf",size:1120000,progress:100,status:"OCR complete"},{id:"f1",name:"Grade6A_Fractions_MiraBose.pdf",type:"application/pdf",size:2450000,progress:100,status:"OCR complete"}],questions:8,reviewed:25,totalReviews:28,quality:78,published:false,version:1},
    {id:"a2",title:"Decimals exit ticket",type:"Exit ticket",grade:"6",section:"B",subject:"Mathematics",maxMarks:10,date:"2026-07-19",stage:"published",files:[],questions:5,reviewed:30,totalReviews:30,quality:86,published:true,version:1}
  ],
  users:[
    {id:"u1",name:"Asha Sharma",email:"asha@sunrise.edu",role:"Teacher",school:"Sunrise Academy",phone:"+91 98765 43210",status:"Active"},
    {id:"u2",name:"Rohan Mehta",email:"rohan@sunrise.edu",role:"Principal",school:"Sunrise Academy",phone:"+91 98765 43211",status:"Active"},
    {id:"u3",name:"Priya Nair",email:"priya@sunrise.edu",role:"Teacher",school:"Sunrise Academy",phone:"+91 98765 43212",status:"Inactive"}
  ],
  interventions:[{id:"i1",assessmentId:"a2",concept:"Decimal place value",format:"Guided practice",duration:"15 minutes",status:"In progress",followup:"2026-07-26"}],
  classes:["Class 6A · Mathematics · 28 students","Class 6B · Mathematics · 30 students","Class 7A · Mathematics · 32 students"],
  schools:["Sunrise Academy · Mumbai · CBSE"],
  students:[{id:"s1",name:"Mira Bose",roll:"6A-12",className:"Class 6A",status:"Active"},{id:"s2",name:"Kabir Shah",roll:"6A-14",className:"Class 6A",status:"Active"},{id:"s3",name:"Riya Menon",roll:"6A-18",className:"Class 6A",status:"Active"},{id:"s4",name:"Aarav Kapoor",roll:"6A-21",className:"Class 6A",status:"Active"}],
  resources:[{id:"r1",title:"Unlike Fractions Recovery Practice",type:"Guided worksheet",status:"Approved",template:"Guided recovery",concept:"Add fractions with unlike denominators",mcq:6,subjective:4,answerSheets:6,gradedSheets:4},{id:"r2",title:"Decimal place-value exit ticket",type:"Exit ticket",status:"Draft",template:"Quick check",concept:"Decimal place value",mcq:4,subjective:2,answerSheets:0,gradedSheets:0}],
  academicYears:["2026–27 · Active","2025–26 · Archived"],
  events:["Demo workspace created"],
  apiLog:[]
};

const stageLabel:Record<Stage,string>={draft:"Draft",uploaded:"Uploaded",setup:"Rubric setup",grading:"AI grading",review:"Teacher review",approved:"Approved",xray:"X-Ray ready",intervention:"Intervention",followup:"Follow-up",published:"Published"};
const teacherNav:TeacherModule[]=["Home","Work","Review","X-Ray","Interventions","Students","Resources","Achievements","Reports","Settings"];
const demoAccounts:DemoProfile[]=[
  {id:"demo-teacher",name:"Asha Sharma",email:"asha@sunrise.demo",role:"Teacher",school:"Sunrise Academy",label:"Teacher demo"},
  {id:"demo-principal",name:"Rohan Mehta",email:"principal@sunrise.demo",role:"Principal",school:"Sunrise Academy",label:"Principal demo"},
  {id:"demo-school-admin",name:"Meera Iyer",email:"admin@sunrise.demo",role:"School admin",school:"Sunrise Academy",label:"School admin demo"},
  {id:"demo-platform-admin",name:"Dev Malhotra",email:"platform@eduai.demo",role:"Platform admin",school:"EduAI Platform",label:"Super admin demo"},
];

function cloneInitial(){return JSON.parse(JSON.stringify(initialState)) as DemoState}
let activeAccessToken="";
function authFetch(input:RequestInfo|URL,init:RequestInit={}){
  const headers=new Headers(init.headers);
  if(activeAccessToken)headers.set("Authorization",`Bearer ${activeAccessToken}`);
  return fetch(input,{...init,headers});
}
function newTeacherState(profile:DemoProfile):DemoState{
  const state=cloneInitial();
  return {
    ...state,
    assessments:[],
    interventions:[],
    resources:[],
    events:[`Teacher workspace created · ${profile.name}`],
    users:[{id:profile.id,name:profile.name,email:profile.email,role:"Teacher",school:profile.school,phone:"",status:"Active"}],
    schools:[`${profile.school} · Teacher workspace`],
  };
}
function logApiTiming(setState:(fn:(s:DemoState)=>DemoState)=>void,timing?:{provider:"mistral"|"openai";ms:number;ok:boolean}[]){
  if(!timing||!timing.length)return;
  setState(s=>({...s,apiLog:[...timing.map(t=>({...t,ts:Date.now()})),...(s.apiLog||[])].slice(0,200)}));
}

// Aggregates every real graded result across all assessments into usable stats.
// Everything downstream (Students, Reports, Interventions, dashboards) should
// read from this instead of hardcoded demo numbers.
function allGradeResults(state:DemoState):GradeResult[]{
  return state.assessments.flatMap(a=>Object.values(a.gradeResults||{}));
}
function classSubjectOptions(state:DemoState):ClassSubjectOption[]{
  const options=new Map<string,ClassSubjectOption>();
  state.classes.forEach(entry=>{
    const parts=entry.split(/Â·|·/).map(part=>part.trim());
    const match=parts[0]?.match(/^(?:Class|Grade)\s+(.+?)([A-Za-z]+)$/i);
    if(!match||!parts[1])return;
    const grade=match[1].trim(),section=match[2].toUpperCase(),subject=parts[1];
    const key=`${grade}|${section}|${subject.toLowerCase()}`;
    options.set(key,{key,classKey:`${grade}|${section}`,grade,section,subject,studentStrength:Number(parts[2]?.match(/\d+/)?.[0]||0)});
  });
  state.assessments.forEach(a=>{
    if(!a.grade||!a.section||!a.subject)return;
    const section=a.section.toUpperCase(),key=`${a.grade}|${section}|${a.subject.toLowerCase()}`;
    if(!options.has(key))options.set(key,{key,classKey:`${a.grade}|${section}`,grade:a.grade,section,subject:a.subject,studentStrength:0});
  });
  return Array.from(options.values()).sort((a,b)=>a.grade.localeCompare(b.grade,undefined,{numeric:true})||a.section.localeCompare(b.section)||a.subject.localeCompare(b.subject));
}
function studentMastery(state:DemoState):Record<string,{mastery:number;evidence:number;lastDate:string}>{
  const results=allGradeResults(state);
  const byStudent:Record<string,{sum:number;count:number;lastDate:string}>={};
  results.forEach(r=>{
    const avgGap=r.gaps.length?r.gaps.reduce((s,g)=>s+g.mastery,0)/r.gaps.length:(r.score/Math.max(1,r.maxMarks))*100;
    const bucket=byStudent[r.studentName]||{sum:0,count:0,lastDate:r.date};
    bucket.sum+=avgGap;bucket.count+=1;if(r.date>bucket.lastDate)bucket.lastDate=r.date;
    byStudent[r.studentName]=bucket;
  });
  const out:Record<string,{mastery:number;evidence:number;lastDate:string}>={};
  Object.entries(byStudent).forEach(([name,b])=>{out[name]={mastery:Math.round(b.sum/b.count),evidence:b.count,lastDate:b.lastDate}});
  return out;
}
function conceptMastery(state:DemoState):{concept:string;mastery:number;evidence:number}[]{
  const results=allGradeResults(state);
  const byConcept:Record<string,{sum:number;count:number}>={};
  results.forEach(r=>r.gaps.forEach(g=>{
    const bucket=byConcept[g.concept]||{sum:0,count:0};
    bucket.sum+=g.mastery;bucket.count+=1;
    byConcept[g.concept]=bucket;
  }));
  return Object.entries(byConcept).map(([concept,b])=>({concept,mastery:Math.round(b.sum/b.count),evidence:b.count})).sort((a,b)=>a.mastery-b.mastery);
}
function overallMastery(state:DemoState):number|null{
  const concepts=conceptMastery(state);
  if(!concepts.length)return null;
  return Math.round(concepts.reduce((s,c)=>s+c.mastery,0)/concepts.length);
}
function masteryTrend(state:DemoState):{label:string;value:number}[]{
  const results=allGradeResults(state).slice().sort((a,b)=>a.date.localeCompare(b.date));
  const byMonth:Record<string,{sum:number;count:number}>={};
  results.forEach(r=>{
    const avgGap=r.gaps.length?r.gaps.reduce((s,g)=>s+g.mastery,0)/r.gaps.length:(r.score/Math.max(1,r.maxMarks))*100;
    const month=r.date.slice(0,7);
    const bucket=byMonth[month]||{sum:0,count:0};
    bucket.sum+=avgGap;bucket.count+=1;
    byMonth[month]=bucket;
  });
  return Object.entries(byMonth).map(([label,b])=>({label,value:Math.round(b.sum/b.count)}));
}

export default function FunctionalEduAIApp(){
  const [client,setClient]=useState<any>(null);
  const [session,setSession]=useState<any>(null);
  const [profile,setProfile]=useState<DemoProfile|null>(null);
  const [needsProfile,setNeedsProfile]=useState(false);
  const [loading,setLoading]=useState(true);
  const [authError,setAuthError]=useState("");

  useEffect(()=>{let alive=true;let unsubscribe:(()=>void)|undefined;void(async()=>{
    try{
      const response=await fetch("/api/auth/config",{cache:"no-store"});
      const config=await response.json();
      if(!response.ok)throw new Error(config.error||"Authentication is unavailable.");
      const supabase=createClient(config.url,config.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
      if(!alive)return;
      setClient(supabase);
      const apply=async(next:any)=>{
        setSession(next);activeAccessToken=next?.access_token||"";
        if(!next){setProfile(null);setNeedsProfile(false);setLoading(false);return}
        setLoading(true);
        const profileResponse=await authFetch("/api/profile",{cache:"no-store"});
        const payload=await profileResponse.json();
        if(!profileResponse.ok)throw new Error(payload.error||"Could not load your profile.");
        if(payload.profile){
          setProfile({id:payload.profile.id,name:payload.profile.name,email:payload.profile.email,role:"Teacher",school:payload.profile.school,label:"Teacher account"});
          setNeedsProfile(false);
        }else{setProfile(null);setNeedsProfile(true)}
        setLoading(false);
      };
      const {data}=await supabase.auth.getSession();
      await apply(data.session);
      const {data:subscription}=supabase.auth.onAuthStateChange((_event:any,next:any)=>{void apply(next).catch(error=>{setAuthError(error.message);setLoading(false)})});
      unsubscribe=()=>subscription.subscription.unsubscribe();
    }catch(error){if(alive){setAuthError(error instanceof Error?error.message:"Authentication failed.");setLoading(false)}}
  })();return()=>{alive=false;unsubscribe?.()}},[]);

  if(loading)return <div className="app-loading"><img src="/brand/logo.png" alt="EduAI Hub"/><b>Preparing your secure workspace…</b></div>;
  if(!session||needsProfile||!profile)return <TeacherAuth client={client} session={session} needsProfile={needsProfile} error={authError} onProfile={next=>{setProfile(next);setNeedsProfile(false)}}/>;
  return <WorkspaceApp profile={profile} onSignOut={async()=>{await client.auth.signOut();activeAccessToken="";setSession(null);setProfile(null)}}/>;
}

function WorkspaceApp({profile,onSignOut}:{profile:DemoProfile;onSignOut:()=>Promise<void>}){
  const [role,setRole]=useState<Role>("Teacher");
  const [module,setModule]=useState<TeacherModule|AdminModule>("Home");
  const [state,setState]=useState<DemoState>(cloneInitial);
  const [selectedId,setSelectedId]=useState("a1");
  const [dialog,setDialog]=useState<string|null>(null);
  const [toast,setToast]=useState<{kind:"success"|"warning"|"error";text:string}|null>(null);
  const [dark,setDark]=useState(false);
  const [ready,setReady]=useState(false);
  const [syncStatus,setSyncStatus]=useState<"Loading"|"Syncing"|"Synced"|"Offline">("Loading");

  useEffect(()=>{void(async()=>{let restored:any=null;try{const response=await authFetch("/api/workspace",{cache:"no-store"});if(response.ok){const payload=await response.json();restored=payload.state;setSyncStatus("Synced")}}catch{}try{if(!restored){const cached=localStorage.getItem(`eduai-xray-offline-cache-v1:${profile.id}`);if(cached)restored=JSON.parse(cached);setSyncStatus("Offline")}if(restored){const base=cloneInitial();setState({...base,...restored,students:restored.students||base.students,resources:(restored.resources||base.resources).map((r:Worksheet)=>({...r,answerSheets:r.answerSheets||0,gradedSheets:r.gradedSheets||0})),academicYears:restored.academicYears||base.academicYears,apiLog:restored.apiLog||[]})}else{setState(newTeacherState(profile));setSelectedId("")}setDark(localStorage.getItem("eduai-theme")==="dark")}catch{}setReady(true)})()},[profile.id]);
  useEffect(()=>{if(!ready)return;localStorage.setItem(`eduai-xray-offline-cache-v1:${profile.id}`,JSON.stringify(state));setSyncStatus("Syncing");const timer=window.setTimeout(()=>{void authFetch("/api/workspace",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({state})}).then(response=>{if(!response.ok)throw new Error("sync failed");setSyncStatus("Synced")}).catch(()=>setSyncStatus("Offline"))},700);return()=>window.clearTimeout(timer)},[state,ready,profile.id]);
  useEffect(()=>{document.documentElement.dataset.theme=dark?"dark":"light";if(ready)localStorage.setItem("eduai-theme",dark?"dark":"light")},[dark,ready]);
  const selected=state.assessments.find(a=>a.id===selectedId)||state.assessments[0];
  const notify=(text:string,kind:"success"|"warning"|"error"="success")=>{setToast({text,kind});window.setTimeout(()=>setToast(null),3200)};
  const updateAssessment=(id:string,patch:Partial<Assessment>)=>setState(s=>({...s,assessments:s.assessments.map(a=>a.id===id?{...a,...patch}:a),events:[`${new Date().toLocaleTimeString()} · ${patch.stage?stageLabel[patch.stage]:"Assessment updated"}`,...s.events].slice(0,20)}));
  const openAssessment=(id:string,next:TeacherModule="Work")=>{setSelectedId(id);setModule(next)};
  const resetDemo=()=>{setState(cloneInitial());setSelectedId("a1");notify("Demo data restored")};
  useEffect(()=>{setModule(role==="Teacher"?"Home":"Overview")},[role]);
  if(!ready)return <div className="app-loading"><img src="/brand/logo.png" alt="EduAI Hub"/><b>Preparing your workspace…</b></div>;

  const nav=role==="Teacher"?teacherNav:role==="School admin"?["Overview","Users","Schools & Classes","Students","Academic years","Branding & Privacy","Reports"] as AdminModule[]:role==="Platform admin"?["Overview","Schools","Users","Analytics","AI Configuration","Feature flags","System health","Audit"] as AdminModule[]:["Overview","Reports"] as AdminModule[];
  const initials=profile.name.split(/\s+/).map(x=>x[0]).join("").slice(0,2).toUpperCase();
  return <div className="app-shell functional-shell">
    <aside className="sidebar">
      <button className="brand" onClick={()=>setModule(role==="Teacher"?"Home":"Overview")}><img src="/brand/shield.png" alt=""/><span><b>Learning X-Ray</b><small>by EduAI Hub</small></span></button>
      <nav aria-label="Primary navigation">{nav.map(item=><button key={item} className={module===item?"active":""} onClick={()=>setModule(item)}><span className="nav-icon">{icon(item)}</span><span>{item}</span>{item==="Review"&&<em>{state.assessments.reduce((n,a)=>n+Math.max(0,a.totalReviews-a.reviewed),0)}</em>}</button>)}</nav>
      <div className="sidebar-foot">
        <button className="secondary full" onClick={()=>setDialog("activity")}>Activity & audit</button>
        <button className="profile" onClick={()=>setDialog("profile")}><span>{initials}</span><div><b>{profile.name}</b><small>{profile.school}</small></div><i>•••</i></button>
      </div>
    </aside>
    <main>
      <header className="topbar">
        <div className="mobile-brand"><img src="/brand/shield.png" alt=""/><b>Learning X-Ray</b></div>
        <div className="crumb"><span>{profile.school}</span><i>›</i><b>{role} workspace</b></div>
        <div className="top-actions">
          <span className={`sync-indicator ${syncStatus.toLowerCase()}`}>{syncStatus==="Synced"?"● Cloud synced":syncStatus==="Syncing"?"◌ Saving…":syncStatus==="Offline"?"○ Offline · queued":"◌ Loading…"}</span>
          <span className="demo-role-badge">{profile.label}</span>
          <button className="demo-signout" onClick={()=>void onSignOut()}>Log out</button>
          <button aria-label="Toggle appearance" onClick={()=>setDark(x=>!x)}>{dark?"☀":"☾"}</button>
          <button aria-label="Notifications" onClick={()=>setDialog("notifications")}>♢{state.events.length>0&&<em>{Math.min(9,state.events.length)}</em>}</button>
        </div>
      </header>
      <div className="content">
        {role==="Teacher"
          ? <TeacherApp profile={profile} module={module as TeacherModule} state={state} selected={selected} openAssessment={openAssessment} open={setDialog} notify={notify} update={updateAssessment} setState={setState}/>
          : role==="School admin"
            ? <SchoolAdminApp module={module as AdminModule} state={state} setState={setState} open={setDialog} notify={notify}/>
            : role==="Principal"
              ? <PrincipalApp module={module as AdminModule} state={state} open={setDialog} notify={notify}/>
              : <PlatformApp module={module as AdminModule} state={state} open={setDialog} notify={notify}/>
        }
      </div>
    </main>
    <nav className="mobile-nav">{nav.slice(0,5).map(item=><button key={item} className={module===item?"active":""} onClick={()=>setModule(item)}><span className="nav-icon">{icon(item)}</span><small>{item}</small></button>)}</nav>
    {toast&&<div className={`toast ${toast.kind}`} role="status"><b>{toast.kind==="error"?"!":"✓"}</b>{toast.text}</div>}
    {dialog&&<AppDialog type={dialog} close={()=>setDialog(null)} open={setDialog} state={state} setState={setState} selected={selected} update={updateAssessment} notify={notify} resetDemo={resetDemo} openAssessment={openAssessment}/>}
  </div>
}

function TeacherAuth({client,session,needsProfile,error,onProfile}:{client:any;session:any;needsProfile:boolean;error:string;onProfile:(profile:DemoProfile)=>void}){
  const [mode,setMode]=useState<"login"|"signup">("login");
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState(error);
  const submitAuth=async(event:FormEvent<HTMLFormElement>)=>{
    event.preventDefault();if(!client)return;
    const data=new FormData(event.currentTarget);
    const email=String(data.get("email")||"").trim().toLowerCase();
    const password=String(data.get("password")||"");
    setBusy(true);setMessage("");
    const result=mode==="signup"
      ? await client.auth.signUp({email,password,options:{emailRedirectTo:`${location.origin}/app`}})
      : await client.auth.signInWithPassword({email,password});
    setBusy(false);
    if(result.error)setMessage(result.error.message);
    else if(mode==="signup"&&!result.data.session)setMessage("Check your email to confirm your account, then return here to log in.");
  };
  const oauth=async(provider:"google"|"azure")=>{
    if(!client)return;setMessage("");
    const {error:oauthError}=await client.auth.signInWithOAuth({provider,options:{redirectTo:`${location.origin}/app`,...(provider==="azure"?{scopes:"email"}:{})}});
    if(oauthError)setMessage(oauthError.message);
  };
  const saveProfile=async(event:FormEvent<HTMLFormElement>)=>{
    event.preventDefault();const data=new FormData(event.currentTarget);setBusy(true);setMessage("");
    const response=await authFetch("/api/profile",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(data))});
    const payload=await response.json();setBusy(false);
    if(!response.ok){setMessage(payload.error||"Could not save your profile.");return}
    onProfile({id:payload.profile.id,name:payload.profile.name,email:payload.profile.email,role:"Teacher",school:payload.profile.school,label:"Teacher account"});
  };
  return <main className="demo-auth">
    <section className="demo-auth-story"><img src="/brand/logo.png" alt="EduAI Hub"/><p className="eyebrow">EduAI Learning X-Ray</p><h1>Your work, securely saved to your teacher account.</h1><p>Grade uploaded answer sheets, identify evidence-based learning gaps, and return later to continue exactly where you stopped.</p><ol><li><b>1</b><span>Sign in securely</span></li><li><b>2</b><span>Create or resume assessments</span></li><li><b>3</b><span>Review AI evidence before publishing</span></li></ol></section>
    <section className="demo-auth-panel"><div className="demo-auth-card">
      {session&&needsProfile?<><p className="eyebrow">First login</p><h2>Complete your teacher profile</h2><p>We’ll use these details to create your private workspace.</p><form onSubmit={saveProfile}><label>Your name<input name="name" required autoFocus/></label><label>School name<input name="school" required/></label><label>Phone (optional)<input name="phone"/></label><label>Subjects taught<input name="subjects" placeholder="e.g. Economics, Business Studies"/></label><label>Classes taught<input name="classes" placeholder="e.g. Class 11 and 12"/></label>{message&&<p className="form-error" role="alert">{message}</p>}<button className="primary full" disabled={busy}>{busy?"Creating workspace…":"Save profile & continue"}</button></form></>:<><p className="eyebrow">Teacher account</p><h2>{mode==="login"?"Welcome back":"Create your account"}</h2><form onSubmit={submitAuth}><label>Email address<input name="email" type="email" autoComplete="email" required/></label><label>Password<input name="password" type="password" minLength={8} autoComplete={mode==="login"?"current-password":"new-password"} required/></label>{message&&<p className="form-error" role="alert">{message}</p>}<button className="primary full" disabled={busy}>{busy?"Please wait…":mode==="login"?"Log in":"Create account"}</button></form><div className="demo-divider"><span>or continue with</span></div><div className="button-row"><button className="secondary" onClick={()=>void oauth("google")}>Google</button><button className="secondary" onClick={()=>void oauth("azure")}>Microsoft</button></div><button className="secondary full" onClick={()=>{setMode(mode==="login"?"signup":"login");setMessage("")}}>{mode==="login"?"New teacher? Create an account":"Already have an account? Log in"}</button></>}
    </div></section>
  </main>;
}

function DemoAccess({accounts,signIn,createTeacher}:{accounts:DemoProfile[];signIn:(account:DemoProfile)=>void;createTeacher:(account:DemoProfile)=>void}){
  const [creating,setCreating]=useState(false);
  const submit=(event:FormEvent<HTMLFormElement>)=>{
    event.preventDefault();
    const data=new FormData(event.currentTarget);
    const name=String(data.get("name")||"").trim();
    const email=String(data.get("email")||"").trim().toLowerCase();
    const school=String(data.get("school")||"").trim();
    createTeacher({id:`teacher-${Date.now()}`,name,email,role:"Teacher",school,label:"New teacher demo"});
  };
  return <main className="demo-auth">
    <section className="demo-auth-story">
      <img src="/brand/logo.png" alt="EduAI Hub"/>
      <p className="eyebrow">EduAI Learning X-Ray · Demo access</p>
      <h1>See each role clearly. Start with the teacher journey.</h1>
      <p>Every account opens role-specific sample data. Create a fresh teacher account to begin with an empty workspace and add your first piece of work.</p>
      <ol><li><b>1</b><span>Create a teacher account</span></li><li><b>2</b><span>Add new work</span></li><li><b>3</b><span>Upload, grade and diagnose gaps</span></li></ol>
      <div className="demo-warning"><b>Demo environment</b><span>These accounts are for product demonstration only and are not production authentication.</span></div>
    </section>
    <section className="demo-auth-panel">
      <div className="demo-auth-card">
        <p className="eyebrow">Start here</p>
        <h2>{creating?"Create your teacher demo":"Choose a demo login"}</h2>
        <p>{creating?"Your new workspace starts empty and opens the Create assessment flow immediately.":"Use the teacher journey first, or inspect another role with seeded demo data."}</p>
        {creating?<form onSubmit={submit}>
          <label>Teacher name<input name="name" required autoFocus placeholder="e.g. Neha Verma"/></label>
          <label>Work email<input name="email" type="email" required placeholder="neha@school.edu"/></label>
          <label>School name<input name="school" required placeholder="e.g. Greenfield School"/></label>
          <button className="primary full" type="submit">Create account & add new work</button>
          <button className="secondary full" type="button" onClick={()=>setCreating(false)}>Back to demo accounts</button>
        </form>:<>
          <button data-testid="create-teacher-account" className="teacher-start" onClick={()=>setCreating(true)}><span>＋</span><div><b>Create a new teacher account</b><small>Empty workspace · opens new work</small></div><i>→</i></button>
          <div className="demo-divider"><span>Or sign in with demo data</span></div>
          <div className="demo-account-list">{accounts.map(account=><button key={account.id} data-testid={`demo-login-${account.role.toLowerCase().replaceAll(" ","-")}`} onClick={()=>signIn(account)}><span>{account.name.split(/\s+/).map(x=>x[0]).join("").slice(0,2)}</span><div><b>{account.label}</b><small>{account.name} · {account.school}</small></div><i>→</i></button>)}</div>
        </>}
        <footer><a href="/privacy">Privacy</a><a href="/terms">Terms</a><span>Demo data · No rankings</span></footer>
      </div>
    </section>
  </main>;
}

function TeacherApp({profile,module,state,selected,openAssessment,open,notify,update,setState}:any){
  if(module==="Home")return <TeacherHome profile={profile} state={state} openAssessment={openAssessment} open={open}/>;
  if(module==="Work")return <Work state={state} setState={setState} selected={selected} openAssessment={openAssessment} open={open} update={update} notify={notify}/>;
  if(module==="Review")return <Review selected={selected} update={update} notify={notify} open={open}/>;
  if(module==="X-Ray")return <XRay state={state} setState={setState} selected={selected} openAssessment={openAssessment} open={open} notify={notify}/>;
  if(module==="Interventions")return <Interventions state={state} setState={setState} open={open} notify={notify}/>;
  if(module==="Students")return <StudentsView state={state} open={open} notify={notify}/>;
  if(module==="Resources")return <ResourcesView state={state} setState={setState} open={open} notify={notify}/>;
  if(module==="Achievements")return <AchievementsView state={state} notify={notify}/>;
  if(module==="Settings")return <SettingsView open={open} notify={notify}/>;
  return <Reports state={state} open={open} notify={notify}/>;
}

function TeacherHome({profile,state,openAssessment,open}:any){
  const pending=state.assessments.reduce((n:any,a:any)=>n+Math.max(0,a.totalReviews-a.reviewed),0);
  const concepts=conceptMastery(state);
  const priorityConcepts=concepts.filter(c=>c.mastery<70);
  const today=new Date().toISOString().slice(0,10);
  const followupsDue=state.interventions.filter((i:Intervention)=>i.status!=="Completed"&&i.followup&&i.followup<=today).length;
  return <><PageHead eyebrow="Teacher workspace" title={`Good morning, ${String(profile?.name||"Teacher").split(" ")[0]}.`} subtitle="Follow the clearest path from evidence to action."><button className="primary" onClick={()=>open("create-assessment")}>＋ Create assessment</button><button className="secondary" onClick={()=>open("upload")}>↑ Upload work</button></PageHead>
    <section className="metric-grid five"><Metric label="Assessments" value={state.assessments.length} note="Persisted securely"/><Metric label="Answers to review" value={pending} note="Teacher judgement"/><Metric label="Priority gaps" value={String(priorityConcepts.length)} note={concepts.length?`Across ${concepts.length} concept${concepts.length===1?"":"s"} with evidence`:"No graded evidence yet"}/><Metric label="Interventions" value={state.interventions.length} note="Active cycles"/><Metric label="Follow-ups due" value={String(followupsDue)} note="Overdue or due today"/></section>
    <div className="dashboard-grid"><section className="card span-2"><CardHead title="Continue your work" eyebrow="Assessment pipeline"><button className="link" onClick={()=>open("create-assessment")}>New assessment →</button></CardHead>
      <div className="table"><div className="tr th"><span>Assessment</span><span>Progress</span><span>Next step</span><span>Status</span></div>{state.assessments.map((a:any)=><button className="tr row-button" key={a.id} onClick={()=>openAssessment(a.id,"Work")}><span><b>{a.title}</b><small>Class {a.grade}{a.section} · {a.subject}</small></span><span>{a.reviewed}/{a.totalReviews||0}</span><span>{nextAction(a.stage)}</span><span><b>{stageLabel[a.stage as Stage]}</b></span></button>)}</div>
    </section><section className="card"><CardHead eyebrow="Recommended next" title={pending?"Review uncertain answers":"Create a new Learning X-Ray"}/><p>AI suggestions remain drafts until you approve them.</p><button className="primary" onClick={()=>openAssessment("a1","Review")}>{pending?"Review next answer":"Open sample X-Ray"} →</button></section></div></>;
}

function Work({state,setState,selected,openAssessment,open,update,notify}:any){
  const [filter,setFilter]=useState("All");
  const list=state.assessments.filter((a:any)=>filter==="All"||stageLabel[a.stage].includes(filter));
  return <><PageHead eyebrow="Teacher workspace" title="Work & evidence" subtitle="Create the assessment and attach its required reference documents before adding student answer sheets."><button className="primary" onClick={()=>open("create-assessment")}>＋ Create assessment</button></PageHead>
    <section className="card span-2 evidence-entry"><div><p className="eyebrow">Assessment-first evidence</p><h2>Keep every analysis grounded in the assessment</h2><p>Creation now captures Class 1–12, the compulsory question paper, and optional marking scheme and model answer. Add student answer sheets after saving.</p></div><div className="evidence-role-list"><span>Question paper · required</span><span>Marking scheme</span><span>Model answer</span><span>Student answers</span></div></section>
    <div className="dashboard-grid"><section className="card span-2"><div className="filters">{["All","Draft","Uploaded","Review","Published"].map(x=><button key={x} className={filter===x?"active":""} onClick={()=>setFilter(x)}>{x}</button>)}</div><div className="work-grid">{list.map((a:any)=><button className={`work-card ${selected?.id===a.id?"selected-card":""}`} key={a.id} onClick={()=>openAssessment(a.id)}><div className="mini-paper"><i/><i/><i/></div><b>{a.title}</b><small>Class {a.grade}{a.section} · {a.subject}</small><Progress value={Math.round(stageProgress(a.stage))}/><span>{stageLabel[a.stage]} →</span></button>)}</div></section>
    {selected&&<AssessmentDecision assessment={selected} open={open} openAssessment={openAssessment}/>}
    {selected&&<AssessmentJourney assessment={selected} open={open}/>}
    {selected&&<UploadedFiles assessment={selected} update={update} notify={notify} open={open}/>}</div></>;
}

function AssessmentDecision({assessment:a,open,openAssessment}:any){
  const graded=assessmentHasGrades(a);
  const learningGaps=()=>graded?openAssessment(a.id,"X-Ray"):open("grade-picker");
  return <section className="card span-2 decision-card"><div><p className="eyebrow">Choose an action</p><h2>{graded?"Graded evidence is ready":"Select an answer sheet to begin"}</h2><p>{graded?"Grade another uploaded sheet or open the visual learning-gap analysis from approved evidence.":"Choose the exact uploaded answer sheet for grading. Learning gaps become available after grading."}</p></div><div className="button-row"><button className="primary" onClick={()=>a.files.length?open("grade-picker"):open("upload")}>Grade answer sheet</button><button className="secondary" onClick={learningGaps}>View learning gaps</button></div></section>
}

function AssessmentJourney({assessment:a,open}:any){
  const steps:[Stage,string,string][]=[["draft","Assessment details","create-assessment"],["uploaded","Student work","upload"],["setup","Questions & rubric","setup"],["grading","AI processing","process"],["review","Teacher review","review-help"],["approved","Final approval","approval"],["xray","Learning X-Ray","xray-details"],["intervention","Intervention","intervention-form"],["followup","Follow-up","followup"],["published","Publish grades","publish"]];
  const current=Object.keys(stageLabel).indexOf(a.stage);
  return <section className="card span-2"><CardHead eyebrow="End-to-end workflow" title={a.title}><span className="status success">Version {a.version}</span></CardHead><div className="journey">{steps.map(([stage,label,action],i)=><button key={stage} className={i<=current?"done":i===current+1?"current":""} onClick={()=>open(action)}><i>{i<current?"✓":i+1}</i><b>{label}</b><small>{i<=current?"Complete":"Open step"}</small></button>)}</div></section>;
}

function Review({selected,update,notify,open}:any){
  const a=selected;
  const results:GradeResult[]=(Object.values(a.gradeResults||{}) as GradeResult[]).sort((x,y)=>x.date.localeCompare(y.date));
  const remaining=Math.max(0,a.totalReviews-a.reviewed);
  const [index,setIndex]=useState(0);
  const current=results.length?results[Math.min(index,results.length-1)]:undefined;
  const gradedFile=current?a.files.find((f:UploadFile)=>f.id===current.fileId):undefined;
  const [mark,setMark]=useState(current?String(current.score):"0");
  const [note,setNote]=useState(current?.feedback||"");
  useEffect(()=>{setMark(current?String(current.score):"0");setNote(current?.feedback||"")},[current?.fileId]);
  const approve=()=>{
    const reviewed=Math.min(a.totalReviews,a.reviewed+1);
    update(a.id,{reviewed,stage:reviewed===a.totalReviews?"approved":"review"});
    notify(reviewed===a.totalReviews?"All answers approved. Final approval is ready.":"Mark approved. Next answer loaded.");
    if(index<results.length-1)setIndex(index+1);
  };
  if(!results.length)return <><PageHead eyebrow={a.title} title="Teacher grading review" subtitle="Compare the original evidence, AI suggestion and rubric before approval."><button className="secondary" onClick={()=>open("grade-picker")}>Grade an answer sheet</button></PageHead>
    <section className="card span-2"><p className="eyebrow">No graded evidence yet</p><h2>Grade an answer sheet to review it here</h2><p>This screen shows the real OCR text, score and rubric evidence from EduAI once you grade a student's answer sheet — there's nothing to review until then.</p></section></>;
  return <><PageHead eyebrow={`${a.title} · Answer ${index+1} of ${results.length}`} title="Teacher grading review" subtitle="Compare the original evidence, AI suggestion and rubric before approval."><button className="secondary" onClick={()=>open("bulk-review")}>Bulk review</button><button className="secondary" onClick={()=>open(`grade-file:${current?.fileId}`)}>Regrade</button></PageHead>
    <div className="review-layout"><section className="card paper-panel"><CardHead eyebrow={`Selected answer sheet · ${gradedFile?.name||"answer sheet"}`} title={`${current?.studentName} · graded against ${current?.questionPaperName||"subject rubric"}`}><span className="status warning">Draft · teacher approval required</span></CardHead><div className="paper">{current?.ocrText?<p className="hand">{current.ocrText}</p>:<p className="hand note">OCR text was not stored for this earlier grading run.</p>}<i className="teacher-mark">{mark}/{current?.maxMarks}</i></div><div className="source-files"><b>Graded answer sheet:</b><span>{gradedFile?.name||"Selected upload"}</span><b>Reference files:</b>{a.files.filter((f:UploadFile)=>f.id!==gradedFile?.id).map((f:UploadFile)=><span key={f.id}>{f.name}</span>)}</div><div className="pager"><button disabled={index===0} onClick={()=>setIndex(Math.max(0,index-1))}>← Previous</button><span>{remaining} remaining</span><button disabled={index>=results.length-1} onClick={()=>setIndex(Math.min(results.length-1,index+1))}>Next →</button></div></section>
    <aside className="card inspector"><p className="eyebrow">AI suggestion · draft · {a.subject}</p><h2>{current?.score} / {current?.maxMarks} marks</h2><div className="evidence"><b>Concept-level evidence</b>{current?.gaps.map(g=><p key={g.concept}>{g.concept}: {g.mastery}% mastery</p>)}</div>{current?.feedback&&<div className="evidence"><b>AI feedback</b><p>{current.feedback}</p></div>}<label>Teacher mark<input type="number" min="0" max={current?.maxMarks} step=".5" value={mark} onChange={e=>setMark(e.target.value)}/></label><label>Teacher note<textarea value={note} onChange={e=>setNote(e.target.value)}/></label><div className="button-row"><button className="secondary" onClick={()=>open(`grade-file:${current?.fileId}`)}>Regrade this answer</button><button className="secondary" onClick={()=>notify("Escalated this assessment to subject coordinator","warning")}>Escalate</button></div><button className="primary full" disabled={!remaining} onClick={approve}>{remaining?"Approve & next":"Review complete ✓"}</button>{!remaining&&<button className="primary full" onClick={()=>open("approval")}>Final approval & publish</button>}<p className="audit-note">OCR + diagnostic grading · {a.subject} rubric · Version {a.version} · teacher decision recorded</p></aside></div></>;
}

function XRay({state,setState,selected,openAssessment,open,notify}:any){
  const options=classSubjectOptions(state);
  const mappedAssessment=selected?.grade&&selected?.section&&selected?.subject?selected:state.assessments.find((assessment:Assessment)=>assessment.grade&&assessment.section&&assessment.subject);
  const initialClassKey=mappedAssessment?`${mappedAssessment.grade}|${mappedAssessment.section.toUpperCase()}`:options[0]?.classKey||"";
  const [classKey,setClassKey]=useState(initialClassKey);
  const [subject,setSubject]=useState(mappedAssessment?.subject||options.find(o=>o.classKey===initialClassKey)?.subject||"");
  const [assessmentId,setAssessmentId]=useState(mappedAssessment?.id||"");
  const classOptions=Array.from(new Map(options.map(o=>[o.classKey,o])).values());
  const subjects=Array.from(new Set(options.filter(o=>o.classKey===classKey).map(o=>o.subject)));
  const effectiveSubject=subjects.includes(subject)?subject:subjects[0]||"";
  const assessments:Assessment[]=state.assessments.filter((a:Assessment)=>`${a.grade}|${a.section.toUpperCase()}`===classKey&&a.subject===effectiveSubject);
  const analysis=assessments.find(a=>a.id===assessmentId)||assessments[0];
  const chooseClass=(nextClass:string)=>{
    const nextSubject=options.find(o=>o.classKey===nextClass)?.subject||"";
    const nextAssessment=state.assessments.find((a:Assessment)=>`${a.grade}|${a.section.toUpperCase()}`===nextClass&&a.subject===nextSubject);
    setClassKey(nextClass);setSubject(nextSubject);setAssessmentId(nextAssessment?.id||"");
  };
  const chooseSubject=(nextSubject:string)=>{
    const nextAssessment=state.assessments.find((a:Assessment)=>`${a.grade}|${a.section.toUpperCase()}`===classKey&&a.subject===nextSubject);
    setSubject(nextSubject);setAssessmentId(nextAssessment?.id||"");
  };
  return <><PageHead eyebrow="Class analysis" title="Class, subject & assessment heatmap" subtitle="Review evidence in the hierarchy: class and section, subject, assessment, then students."><button className="primary" onClick={()=>open("class")}>＋ Create class & subject</button><button className="secondary" onClick={()=>open("create-assessment")}>＋ Create assessment</button></PageHead>
    <section className="card analysis-scope" aria-label="Visual learning-gap report"><CardHead eyebrow="Analysis scope" title="Class & section → Subject → Assessment → Students"/><div className="analysis-scope-grid">
      <Field label="Class & section"><select value={classKey} onChange={e=>chooseClass(e.target.value)}>{classOptions.map(o=><option key={o.classKey} value={o.classKey}>Class {o.grade}{o.section}</option>)}</select></Field>
      <Field label="Subject"><select value={effectiveSubject} onChange={e=>chooseSubject(e.target.value)} disabled={!subjects.length}>{subjects.map(item=><option key={item}>{item}</option>)}</select></Field>
      <Field label="Assessment"><select value={analysis?.id||""} onChange={e=>setAssessmentId(e.target.value)} disabled={!assessments.length}>{assessments.map(a=><option key={a.id} value={a.id}>{a.title} · {a.date}</option>)}</select></Field>
    </div><p className="analysis-scope-note">Every analysis is linked to a saved assessment with a compulsory question paper and its Class master record.</p></section>
    {!analysis?<section className="card"><p className="eyebrow">No assessment evidence yet</p><h2>Create the assessment first</h2><p>Add its Class, subject, question paper, marking scheme, and model answer before uploading student responses.</p><button className="primary" onClick={()=>open("create-assessment")}>Create assessment</button></section>:<AssessmentHeatmap selected={analysis} open={open} notify={notify}/>}
  </>;
}

function AssessmentHeatmap({selected,open,notify}:any){
  const results:GradeResult[]=Object.values(selected.gradeResults||{});
  const hasData=results.length>0;

  // Aggregate mastery per concept across every real graded result.
  const conceptTotals:{[concept:string]:{sum:number;count:number}}={};
  results.forEach(r=>r.gaps.forEach(g=>{
    const bucket=conceptTotals[g.concept]||{sum:0,count:0};
    bucket.sum+=g.mastery;bucket.count+=1;
    conceptTotals[g.concept]=bucket;
  }));
  const concepts=Object.keys(conceptTotals);
  const avgFor=(c:string)=>Math.round(conceptTotals[c].sum/conceptTotals[c].count);
  const sortedConcepts=concepts.slice().sort((a,b)=>avgFor(a)-avgFor(b));
  const priorityConcept=sortedConcepts[0];
  const classMastery=concepts.length?Math.round(concepts.reduce((s,c)=>s+avgFor(c),0)/concepts.length):0;
  const priorityStudents=results.filter(r=>r.gaps.some(g=>g.concept===priorityConcept&&g.mastery<70));
  const students=Array.from(new Set(results.map(r=>r.studentName)));
  const clusterMap=new Map<string,string[]>();
  results.forEach(r=>{const signature=r.gaps.filter(g=>g.mastery<70).sort((a,b)=>a.mastery-b.mastery).slice(0,2).map(g=>g.concept).join(" + ")||"Monitor only";clusterMap.set(signature,[...(clusterMap.get(signature)||[]),r.studentName])});
  const clusters=Array.from(clusterMap.entries()).sort((a,b)=>b[1].length-a[1].length);

  const lastGradedFileId=selected.lastGradedFileId||results[0]?.fileId;
  return <><div className="assessment-analysis-actions"><div><p className="eyebrow">Selected assessment · Students</p><h2>{selected.title}</h2><span>Class {selected.grade}{selected.section} · {selected.subject} · {results.length} analysed student{results.length===1?"":"s"}</span></div><div className="button-row"><button className="secondary" disabled={!hasData} onClick={()=>downloadClassLearningGapReport(selected,results)}>Download Learning Gap Report</button><button className="primary" disabled={!hasData} onClick={()=>open(`study-guide:${lastGradedFileId}`)}>Create study guide</button><button className="secondary" onClick={()=>open("worksheet")}>Build gap worksheet</button><button className="secondary" onClick={()=>open("quality")}>Assessment quality</button></div></div>
  {!hasData&&<section className="card span-2"><p className="eyebrow">No graded evidence yet</p><h2>Grade at least one answer sheet to see real learning gaps</h2><p>This report is built entirely from Mistral-graded results for {selected.subject}. Once you grade a student's answer sheet, their concept-level gaps will appear here instead of placeholder data.</p></section>}
  {hasData&&<section className="executive-summary"><p className="eyebrow">Executive summary</p><h3>Learning gaps requiring attention</h3><ul>{sortedConcepts.map(concept=><li key={concept}><b>{concept}</b> — {avgFor(concept)}% average mastery</li>)}</ul></section>}
  {hasData&&<div className="dashboard-grid"><section className="card span-2 branded-report"><BrandDocumentHeader label="Learning gap report" title={selected.title} meta={`${selected.subject} · ${results.length} analysed answer sheet${results.length===1?"":"s"}`}/><div className="source-ribbon"><b>Evidence used</b>{selected.files.map((file:UploadFile)=><span key={file.id}>{file.documentRole||inferDocumentRole(file.name)} · {file.name}</span>)}</div><div className="xray-summary"><Metric label="Class mastery" value={`${classMastery}%`} note="Graded evidence"/><Metric label="Priority concepts" value={String(sortedConcepts.filter(c=>avgFor(c)<70).length)} note={`${priorityStudents.length} students`}/><Metric label="Confidence" value={results.length>2?"High":results.length>1?"Medium":"Low"} note={`${results.length} evidence point${results.length===1?"":"s"}`}/><Metric label="Quality" value={`${selected.quality||0}%`} note="Suitable with limitations"/></div><div className="gap-clusters"><div className="cluster-heading"><b>Dynamic intervention groups</b><span>Students with similar priority gaps</span></div>{clusters.map(([label,names],index)=><button key={label} onClick={()=>notify(`${label}: ${names.join(", ")}`)}><i>Group {index+1}</i><b>{label}</b><span>{names.join(" · ")}</span></button>)}</div><div className="heatmap" style={{gridTemplateColumns:`100px repeat(${Math.max(1,concepts.length)},minmax(72px,1fr))`}}><div/>{concepts.map(c=><b key={c}>{c}</b>)}{students.flatMap((s)=>[<span key={s}>{s}</span>,...concepts.map((c)=>{const r=results.find(x=>x.studentName===s);const g=r?.gaps.find(x=>x.concept===c);const v=g?g.mastery:null;const band=v===null?"review":v>=80?"excellent":v<=35?"weak":"average";return <button key={c+s} className={band} disabled={v===null} aria-label={`${s}, ${c}, ${v===null?"not assessed":`${v}% ${band}`}`} onClick={()=>open(`evidence:${encodeURIComponent(s)}:${encodeURIComponent(c)}`)}>{v===null?"—":`${v}%`}</button>})])}</div><div className="heat-legend" aria-label="Heatmap performance categories"><span><i className="weak"/>Weak · 35% or less</span><span><i className="average"/>Average · 36% to 79%</span><span><i className="excellent"/>Excellent · 80% or above</span><span><i className="review"/>Not assessed</span></div></section>
  <section className="card"><p className="eyebrow">Priority gap</p><h2>{priorityConcept||"No concept identified yet"}</h2><div className="big-stat">{priorityStudents.length} <small>students</small></div><p>{priorityConcept?`Lowest average mastery across graded evidence for ${selected.subject}: ${avgFor(priorityConcept)}%.`:"Grade more answer sheets to surface a priority concept."}</p><div className="gap-funnel">{sortedConcepts.slice(0,3).map(c=><span key={c} className={avgFor(c)<60?"critical":""}><i style={{width:`${avgFor(c)}%`}}/>{c} · {avgFor(c)}%</span>)}</div><button className="secondary" disabled={!priorityStudents.length} onClick={()=>open(`evidence:${encodeURIComponent(priorityStudents[0]?.studentName||"")}:${encodeURIComponent(priorityConcept||"")}`)}>View student evidence</button><button className="primary" disabled={!priorityConcept} onClick={()=>open(`study-guide:${lastGradedFileId}`)}>Generate study guide</button></section>
  <section className="card"><p className="eyebrow">Teacher authority</p><h2>Approve diagnosis</h2><label>Classification<select><option>Priority learning gap</option><option>Developing</option><option>Possible performance issue</option><option>Insufficient evidence</option></select></label><label>Observation<select><option>No additional observation</option><option>Time issue</option><option>Language issue</option><option>Careless error</option></select></label><button className="primary" onClick={()=>notify("Diagnosis approved and stored in the audit trail")}>Approve X-Ray</button></section></div>}</>;
}

function Interventions({state,setState,open,notify}:any){
  const complete=(id:string)=>{setState((s:DemoState)=>({...s,interventions:s.interventions.map(i=>i.id===id?{...i,status:"Completed"}:i),events:["Intervention completed",...s.events]}));notify("Intervention marked complete. Record follow-up evidence next.")};
  const concepts=conceptMastery(state);
  const completedCount=state.interventions.filter((i:Intervention)=>i.status==="Completed").length;
  const followupRate=state.interventions.length?Math.round((completedCount/state.interventions.length)*100):0;
  return <><PageHead eyebrow="Improvement cycle" title="Interventions & follow-up" subtitle="Temporary, concept-specific support linked to measurable evidence."><button className="primary" onClick={()=>open("intervention-form")}>＋ Create intervention</button><button className="secondary" onClick={()=>open("worksheet")}>Generate worksheet</button></PageHead>
  <div className="dashboard-grid">{state.interventions.map((i:any)=>{const evidence=concepts.find(c=>c.concept===i.concept);return <section className="card" key={i.id}><span className={`status ${i.status==="Completed"?"success":"warning"}`}>{i.status}</span><p className="eyebrow">Temporary group · Strengthen</p><h2>{i.concept}</h2><p>{i.format} · {i.duration} · {evidence?`${evidence.evidence} evidence point${evidence.evidence===1?"":"s"}`:"No graded evidence yet"}</p><p>Follow-up: {i.followup}</p>{i.followupRecorded&&i.followupEvidence&&<p className="modal-copy">Recorded outcome: {i.followupEvidence.outcome} · {i.followupEvidence.studentsCompleted} students · {i.followupEvidence.avgMastery}% avg mastery</p>}<div className="button-row"><button className="secondary" onClick={()=>open(`group:${i.assessmentId}:${encodeURIComponent(i.concept)}`)}>Review group</button>{i.status!=="Completed"?<button className="primary" onClick={()=>complete(i.id)}>Mark complete</button>:<button className="primary" onClick={()=>open(`followup:${i.id}`)}>{i.followupRecorded?"Follow-up recorded ✓":"Record follow-up"}</button>}</div></section>})}
  <section className="card"><p className="eyebrow">Resource studio</p><h2>Generate teacher-approved materials</h2><p>Worksheets, exit tickets, guided examples and answer keys remain drafts until approval.</p><button className="primary" onClick={()=>open("worksheet")}>Generate resource</button></section>
  <section className="card span-2"><CardHead eyebrow="Progress tracking" title="Concept mastery from graded evidence"/>{concepts.length?<div className="quality-bars">{concepts.slice(0,3).map(c=><Bar key={c.concept} label={c.concept} pct={c.mastery}/>)}<Bar label="Intervention follow-up completion" pct={followupRate}/></div>:<p className="modal-copy">No graded evidence yet — grade answer sheets to see real concept mastery here.</p>}</section></div></>;
}

function Reports({state,open,notify}:any){
  const [tab,setTab]=useState("Student performance");const tabs=["Student performance","Class heatmap","Concept mastery","Learning gaps","Teacher summary","School dashboard"];
  const concepts=conceptMastery(state);
  const trend=masteryTrend(state);
  return <><PageHead eyebrow="Reports" title="Evidence-led reporting" subtitle="Interactive views with quality, privacy and limitation context."><button className="primary" onClick={()=>open("report")}>＋ Generate report</button></PageHead>
  <div className="filters">{tabs.map(x=><button key={x} className={tab===x?"active":""} onClick={()=>setTab(x)}>{x}</button>)}</div>
  <div className="dashboard-grid"><section className="card span-2"><CardHead eyebrow={tab} title={reportTitle(tab)}><button className="secondary" onClick={()=>notify(`${tab} exported as a demo report`)}>Export</button></CardHead>
  {!concepts.length&&<p className="modal-copy">No graded evidence yet. Grade answer sheets to populate real reports here.</p>}
  {concepts.length>0&&(tab.includes("heatmap")||tab.includes("mastery")?<div className="concept-bars">{concepts.map(c=><Bar key={c.concept} label={c.concept} pct={c.mastery}/>)}</div>:trend.length?<div className="chart" aria-label="Performance trend chart">{trend.map((t,i)=><button key={t.label} style={{height:`${t.value}%`}} onClick={()=>notify(`${t.label}: ${t.value}% mastery`)} aria-label={`${t.label}, ${t.value}%`}/>)}</div>:<p className="modal-copy">Grade evidence across more than one date to see a trend.</p>)}</section>
  <section className="card"><p className="eyebrow">Secure sharing</p><h2>Leadership report</h2><label>Expiry<select><option>7 days</option><option>30 days</option><option>90 days</option></select></label><label className="check"><input type="checkbox" defaultChecked/> Require access code</label><label className="check"><input type="checkbox"/> Allow download</label><button className="primary" onClick={()=>open("share-report")}>Create secure link</button></section>
  <section className="card"><p className="eyebrow">Data safeguards</p><h2>Context included</h2><ul className="checklist"><li>No teacher or student ranking</li><li>Assessment limitations disclosed</li><li>Teacher-approved evidence only</li><li>Revocable access</li></ul></section></div></>;
}

function StudentsView({state,open,notify}:any){
  const [query,setQuery]=useState("");const students=state.students.filter((s:any)=>`${s.name} ${s.roll} ${s.className}`.toLowerCase().includes(query.toLowerCase()));
  const mastery=studentMastery(state);
  return <><PageHead eyebrow="Assigned classes only" title="Students & evidence" subtitle="Review evidence and progress without permanent ability labels."><button className="secondary" onClick={()=>open("import-students")}>Import roster</button><button className="primary" onClick={()=>open("student")}>＋ Add student</button></PageHead><section className="card"><CardHead eyebrow="Class 6A · Mathematics" title="Student roster"><input className="compact-input" placeholder="Search name or roll number" value={query} onChange={e=>setQuery(e.target.value)}/></CardHead><div className="user-table">{students.map((s:any)=>{const m=mastery[s.name];return <button className="user-row student-row" key={s.id} onClick={()=>open(`student-evidence:${s.id}`)}><span className="avatar">{s.name.split(" ").map((x:string)=>x[0]).join("")}</span><div><b>{s.name}</b><small>{s.roll} · {s.className}</small></div><span>{m?`${m.mastery}% mastery`:"No evidence yet"}</span><span className="status success">{s.status}</span><span className="link">View evidence →</span></button>})}</div></section></>;
}

function ResourcesView({state,setState,open,notify}:any){
  const [classFilter,setClassFilter]=useState("All classes");
  const [subjectFilter,setSubjectFilter]=useState("All subjects");
  const [assessmentFilter,setAssessmentFilter]=useState("All assessments");
  const classes=Array.from(new Set(state.assessments.map((a:Assessment)=>`Class ${a.grade}${a.section}`))).sort();
  const subjects=Array.from(new Set(state.assessments.filter((a:Assessment)=>classFilter==="All classes"||`Class ${a.grade}${a.section}`===classFilter).map((a:Assessment)=>a.subject))).sort();
  const assessments:Assessment[]=state.assessments.filter((a:Assessment)=>(classFilter==="All classes"||`Class ${a.grade}${a.section}`===classFilter)&&(subjectFilter==="All subjects"||a.subject===subjectFilter));
  const rows=assessments.filter(a=>assessmentFilter==="All assessments"||a.id===assessmentFilter).flatMap(a=>Object.values(a.gradeResults||{}).map(result=>{
    const guide=state.resources.find((r:Worksheet)=>r.type==="Study Guide"&&(r.assessmentId===a.id||r.id===`guide-${a.id}-${result.fileId}`)&&(r.studentName===result.studentName||!r.studentName));
    const worksheet=state.resources.find((r:Worksheet)=>r.type!=="Study Guide"&&(r.assessmentId===a.id||r.id.includes(`${a.id}-${result.fileId}`))&&(r.studentName===result.studentName||!r.studentName));
    return {assessment:a,result,guide,worksheet};
  }));
  return <><PageHead eyebrow="Saved reports & learning materials" title="Resource library" subtitle="Filter by class, subject and assessment, then download each student's report and learning materials."><button className="primary" onClick={()=>open("worksheet")}>＋ Create worksheet</button></PageHead>
    <section className="card resource-library">
      <div className="resource-filters" aria-label="Resource filters">
        <Field label="Class"><select aria-label="Filter resources by class" value={classFilter} onChange={e=>{setClassFilter(e.target.value);setSubjectFilter("All subjects");setAssessmentFilter("All assessments")}}><option>All classes</option>{classes.map(x=><option key={x}>{x}</option>)}</select></Field>
        <Field label="Subject"><select aria-label="Filter resources by subject" value={subjectFilter} onChange={e=>{setSubjectFilter(e.target.value);setAssessmentFilter("All assessments")}}><option>All subjects</option>{subjects.map(x=><option key={x}>{x}</option>)}</select></Field>
        <Field label="Assessment"><select aria-label="Filter resources by assessment" value={assessmentFilter} onChange={e=>setAssessmentFilter(e.target.value)}><option value="All assessments">All assessments</option>{assessments.map(a=><option value={a.id} key={a.id}>{a.title}</option>)}</select></Field>
      </div>
      <div className="resource-table" role="table" aria-label="Student reports and documents">
        <div className="resource-row resource-head" role="row"><span role="columnheader">Student name</span><span role="columnheader">Learning gap report</span><span role="columnheader">Study guide</span><span role="columnheader">Worksheet & answer key</span></div>
        {!rows.length&&<div className="empty-state"><b>No analysed students match these filters</b><p>Grade an answer sheet or change the filters to view downloadable resources.</p></div>}
        {rows.map(({assessment,result,guide,worksheet})=><div className="resource-row" role="row" key={`${assessment.id}-${result.fileId}`}>
          <span role="cell"><b>{result.studentName}</b><small>Class {assessment.grade}{assessment.section} · {assessment.subject}<br/>{assessment.title}</small></span>
          <span role="cell"><button className="link" onClick={()=>downloadStudentLearningGapReport(assessment,result)}>Download report</button></span>
          <span role="cell">{guide?<button className="link" onClick={()=>downloadStudyGuide(guide,guide.guide)}>Download study guide</button>:<small>Not created</small>}</span>
          <span role="cell">{worksheet?<div className="resource-actions"><button className="link" onClick={()=>downloadWorksheet(worksheet,worksheet.content)}>Worksheet</button><button className="link" onClick={()=>downloadAnswerKey(worksheet,worksheet.content)}>Answer key</button></div>:<small>Not created</small>}</span>
        </div>)}
      </div>
    </section>
  </>;
}

function AchievementsView({state,notify}:any){
  const results=allGradeResults(state);
  const completedInterventions=state.interventions.filter((i:Intervention)=>i.status==="Completed").length;
  const followupRate=state.interventions.length?Math.round((completedInterventions/state.interventions.length)*100):0;
  const avgQuality=state.assessments.length?Math.round(state.assessments.reduce((s:number,a:Assessment)=>s+(a.quality||0),0)/state.assessments.length):0;
  const badges=[
    ["First Learning X-Ray",results.length?"Completed":"Not yet — grade an answer sheet"],
    ["Intervention Planner",completedInterventions?"Completed":"Not yet — complete an intervention"],
    ["Evidence-Based Teacher",`${Math.min(completedInterventions,5)} of 5 cycles`],
    ["Assessment Quality Champion",`${avgQuality}% avg quality`],
    ["Answer sheets graded",`${results.length} graded`]
  ];
  return <><PageHead eyebrow="Progress without competition" title="Achievements" subtitle="Recognition rewards evidence quality, follow-up and improvement—not upload volume."><button className="secondary" onClick={()=>notify("Weekly progress summary prepared")}>Weekly summary</button></PageHead><section className="metric-grid"><Metric label="Improvement cycles" value={String(completedInterventions)} note="Completed"/><Metric label="Answer sheets graded" value={String(results.length)} note="EduAI analysis"/><Metric label="Follow-up completion" value={`${followupRate}%`} note="This term"/><Metric label="Avg assessment quality" value={`${avgQuality}%`} note="Across all assessments"/></section><div className="achievement-grid">{badges.map(([name,status],i)=><button key={name} onClick={()=>notify(`${name}: ${status}`)}><i>{["✦","↗","✓","◎","◷"][i]}</i><b>{name}</b><small>{status}</small></button>)}</div><p className="insight">No teacher or student leaderboard is used. School challenges and celebrations can be disabled by administrators.</p></>;
}

function SettingsView({open}:any){
  const items=[["Profile & onboarding","Personal, teaching and school details","profile"],["Grading preferences","Strictness, partial credit, spelling and units","grading-settings"],["Appearance & accessibility","Theme, contrast, text and reduced motion","appearance-settings"],["Notifications","Processing, intervention and follow-up reminders","notification-settings"],["Privacy & consent","Terms, AI disclosure and product-improvement consent","consent-settings"],["Sessions & security","Login history and log out all devices","security-settings"]];
  return <><PageHead eyebrow="Teacher preferences" title="Settings" subtitle="Control grading, notifications, accessibility, privacy and account security."/><div className="settings-grid">{items.map(([title,sub,type])=><button key={title} onClick={()=>open(type)}><b>{title}</b><small>{sub}</small><span>Manage →</span></button>)}</div></>;
}

function SchoolAdminApp({module,state,setState,open,notify}:any){
  const toggle=(id:string)=>{setState((s:DemoState)=>({...s,users:s.users.map(u=>u.id===id?{...u,status:u.status==="Active"?"Inactive":"Active"}:u)}));notify("User status updated")};
  return <><PageHead eyebrow="School administrator" title={module} subtitle="Manage people, school structure and access with a clear audit trail.">{module==="Users"&&<button className="primary" onClick={()=>open("invite")}>＋ Invite user</button>}{module==="Schools & Classes"&&<button className="primary" onClick={()=>open("class")}>＋ Add class</button>}</PageHead>
  {module==="Overview"&&<><section className="metric-grid"><Metric label="Users" value={state.users.length} note="Across all roles"/><Metric label="Invitations" value={state.users.filter((u:any)=>u.status==="Invited").length} note="Pending"/><Metric label="Classes" value={state.classes.length} note="Current year"/><Metric label="Schools" value={state.schools.length} note="Active tenant"/></section><div className="dashboard-grid"><section className="card span-2"><CardHead eyebrow="Admin actions" title="School setup"/><div className="admin-actions"><button onClick={()=>open("invite")}>Invite user<span>Name, email, role and school</span></button><button onClick={()=>open("class")}>Add class<span>Class, section and subject</span></button><button onClick={()=>open("school")}>Manage school<span>Profile, board and branding</span></button><button onClick={()=>open("privacy-settings")}>Privacy & retention<span>Access and data policy</span></button></div></section></div></>}
  {module==="Users"&&<section className="card"><CardHead eyebrow="People & access" title="Users"><input className="compact-input" placeholder="Search users" onChange={()=>{}}/></CardHead><div className="user-table">{state.users.map((u:any)=><div className="user-row" key={u.id}><span className="avatar">{u.name.split(" ").map((x:string)=>x[0]).join("").slice(0,2)}</span><div><b>{u.name}</b><small>{u.email} · {u.school}</small></div><span>{u.role}</span><span className={`status ${u.status==="Active"?"success":u.status==="Invited"?"warning":""}`}>{u.status}</span><div className="button-row"><button className="link" onClick={()=>open(`edit-user:${u.id}`)}>Edit</button><button className="link" onClick={()=>open(`reset-user:${u.id}`)}>Reset password</button><button className="link" onClick={()=>toggle(u.id)}>{u.status==="Active"?"Deactivate":"Activate"}</button></div></div>)}</div></section>}
  {module==="Schools & Classes"&&<div className="dashboard-grid"><section className="card"><CardHead eyebrow="School profile" title="Schools"><button className="link" onClick={()=>open("school")}>Edit</button></CardHead>{state.schools.map((x:any)=><div className="list-item" key={x}><b>{x}</b><button onClick={()=>open("school")}>Manage</button></div>)}</section><section className="card"><CardHead eyebrow="Academic structure" title="Classes"><button className="link" onClick={()=>open("class")}>Add</button></CardHead>{state.classes.map((x:any)=><div className="list-item" key={x}><b>{x}</b><button onClick={()=>open("class")}>Edit</button></div>)}</section></div>}
  {module==="Students"&&<StudentsView state={state} open={open} notify={notify}/>}
  {module==="Academic years"&&<section className="card"><CardHead eyebrow="School calendar" title="Academic years"><button className="primary" onClick={()=>open("academic-year")}>＋ Add year</button></CardHead>{state.academicYears.map((x:string)=><div className="list-item" key={x}><b>{x}</b><div className="button-row"><button onClick={()=>open("academic-year")}>Edit</button><button onClick={()=>notify("Academic year status updated")}>Change status</button></div></div>)}</section>}
  {module==="Branding & Privacy"&&<div className="settings-grid">{[["School branding","Logo, report cover and co-branding","school"],["Privacy & retention","Retention, recovery and deletion","privacy-settings"],["Login-provider policy","Google, Microsoft and email fallback","security-settings"],["Notifications","Frequency and templates","notification-settings"],["Support access","Reason, named agent and expiry","support-access"],["Report settings","Expiry, download and OTP defaults","report-settings"]].map(([a,b,c])=><button key={a} onClick={()=>open(c)}><b>{a}</b><small>{b}</small><span>Manage →</span></button>)}</div>}
  {module==="Reports"&&<Reports state={state} open={open} notify={notify}/>}</>;
}

function PrincipalApp({module,state,open,notify}:any){
  if(module==="Reports")return <Reports state={state} open={open} notify={notify}/>;
  const concepts=conceptMastery(state);
  const priorityGaps=concepts.filter(c=>c.mastery<70).length;
  const completed=state.interventions.filter((i:Intervention)=>i.status==="Completed").length;
  const interventionRate=state.interventions.length?Math.round((completed/state.interventions.length)*100):0;
  const mastery=overallMastery(state);
  const trend=masteryTrend(state);
  return <><PageHead eyebrow="Principal workspace" title="School academic improvement" subtitle="Aggregated, non-punitive insight for planning academic support."><button className="primary" onClick={()=>open("report")}>Generate leadership report</button></PageHead><section className="metric-grid"><Metric label="Students in roster" value={String(state.students.length)} note="Assigned classes"/><Metric label="Priority gaps" value={String(priorityGaps)} note={`Across ${concepts.length} concept${concepts.length===1?"":"s"}`}/><Metric label="Interventions complete" value={`${interventionRate}%`} note={`${completed} of ${state.interventions.length}`}/><Metric label="Overall mastery" value={mastery===null?"No data":`${mastery}%`} note="Graded evidence"/></section><div className="dashboard-grid"><section className="card span-2"><CardHead eyebrow="School trend" title="Mastery from graded evidence"/>{trend.length?<div className="chart">{trend.map(t=><button key={t.label} style={{height:`${t.value}%`}} onClick={()=>notify(`${t.label}: ${t.value}% mastery evidence`)}/>)}</div>:<p className="modal-copy">No graded evidence yet across more than one date.</p>}</section><section className="card"><p className="eyebrow">Management action</p><h2>Protect remedial time</h2><p>{concepts[0]?`${concepts[0].concept} is currently the lowest-mastery concept with graded evidence (${concepts[0].mastery}%).`:"No graded evidence yet to identify a priority concept."}</p><button className="primary" onClick={()=>notify("Action assigned to academic head")}>Assign action</button></section></div></>;
}

function SystemHealthPanel({state}:{state:DemoState}){
  const [checking,setChecking]=useState(false);
  const [live,setLive]=useState<{checkedAt:string;providers:{provider:string;ok:boolean;ms:number;status?:number;error?:string}[]}|null>(null);
  const [liveError,setLiveError]=useState("");
  const runCheck=async()=>{
    setChecking(true);setLiveError("");
    try{
      const res=await fetch("/api/system-health");
      const payload=await res.json();
      if(!res.ok)throw new Error(payload?.error||"Health check failed");
      setLive(payload);
    }catch(err){
      setLiveError(err instanceof Error?err.message:"Health check failed");
    }finally{
      setChecking(false);
    }
  };
  const log=state.apiLog||[];
  const byProvider=(p:"mistral"|"openai")=>log.filter(l=>l.provider===p);
  const stats=(p:"mistral"|"openai")=>{
    const entries=byProvider(p);
    if(!entries.length)return null;
    const ok=entries.filter(e=>e.ok).length;
    const avgMs=Math.round(entries.reduce((s,e)=>s+e.ms,0)/entries.length);
    return {count:entries.length,successRate:Math.round((ok/entries.length)*100),avgMs};
  };
  const mistralStats=stats("mistral");
  const openaiStats=stats("openai");
  return <section className="card span-2">
    <CardHead eyebrow="System health" title="Live provider status"/>
    <p className="modal-copy">This checks the OCR and learning-analysis services with a real request and reports what actually comes back — no simulated numbers.</p>
    <button className="secondary" onClick={runCheck} disabled={checking}>{checking?"Checking…":"Check live status now"}</button>
    {liveError&&<p className="form-error" role="alert">{liveError}</p>}
    {live&&<div>
      {live.providers.map(p=><div className="list-item" key={p.provider}><b>{p.provider==="mistral"?"OCR service":"Learning analysis"}</b><span className={`status ${p.ok?"success":"warning"}`}>{p.ok?`Reachable · ${p.ms}ms`:`Unreachable${p.error?` · ${p.error}`:""}`}</span></div>)}
      <p className="modal-copy">Checked at {new Date(live.checkedAt).toLocaleTimeString()}.</p>
    </div>}
    <h2>Real usage this session</h2>
    <p className="modal-copy">Success rate and latency computed from every real grading and worksheet-generation call this app has actually made — not projected or simulated.</p>
    <div>
      <div className="list-item"><b>Mistral OCR</b><span className="status neutral">{mistralStats?`${mistralStats.successRate}% success · ${mistralStats.avgMs}ms avg · ${mistralStats.count} call${mistralStats.count===1?"":"s"}`:"No calls made yet this session"}</span></div>
      <div className="list-item"><b>Learning analysis</b><span className="status neutral">{openaiStats?`${openaiStats.successRate}% success · ${openaiStats.avgMs}ms avg · ${openaiStats.count} call${openaiStats.count===1?"":"s"}`:"No calls made yet this session"}</span></div>
    </div>
    <p className="modal-copy">Long-term uptime (30/90-day %) and queue depth still require a real monitoring backend with persistent storage across sessions — that's genuinely out of scope for this frontend-only build, not faked.</p>
  </section>;
}
function PlatformApp({module,state,open,notify}:any){
  const configs:{[key:string]:string[]}={Overview:["Tenant management","Usage analytics","AI providers","Model routing","Prompt versions","Academic configuration","Feature flags","Gamification","Notifications","Privacy","System health","Audit logs"],Schools:["Search schools","Plans & limits","Suspend / reactivate","Pilot status","Support owner","Internal notes"],Users:["Search users","Suspend access","Reset access","Login history","Terms version","Platform roles"],Analytics:["DAU / WAU / MAU","Assessments & pages","AI acceptance & changes","Regrading","X-Rays & interventions","Time saved & AI cost"],"AI Configuration":["Provider registry","Model registry","Routing rules","Prompt versions","Output schemas","Fallback sequence"],"Feature flags":["AI grading","Handwriting recognition","Regrading","Gamification","Principal reporting","Experimental models"],"System health":["API uptime","Queue depth","Provider latency","Database & storage","Failed jobs","Active incidents"],Audit:["Authentication","Configuration changes","Support access","Tenant changes","AI versions","Retention actions"]};
  const items=configs[module]||configs.Overview;
  const totalFiles=state.assessments.reduce((s:number,a:Assessment)=>s+(a.files?.length||0),0);
  const results=allGradeResults(state);
  const reviewRatio=state.assessments.length?Math.round(state.assessments.reduce((s:number,a:Assessment)=>s+(a.totalReviews?a.reviewed/a.totalReviews:0),0)/state.assessments.length*100):null;
  return <><PageHead eyebrow="EduAI Hub platform administrator" title={module==="Overview"?"Platform operations":module} subtitle="Tenant health, responsible AI operations and auditable configuration."><button className="primary" onClick={()=>open("platform-config")}>＋ Configure</button></PageHead><section className="metric-grid"><Metric label="Active schools" value={String(state.schools.length)} note="This tenant"/><Metric label="Files processed" value={String(totalFiles)} note="Uploaded to assessments"/><Metric label="Graded evidence" value={String(results.length)} note="EduAI analysis"/><Metric label="Teacher review rate" value={reviewRatio===null?"No data":`${reviewRatio}%`} note="Avg across assessments"/></section><div className="dashboard-grid">{module==="System health"?<SystemHealthPanel state={state}/>:<section className="card span-2"><CardHead eyebrow={module} title="Controls & evidence"/><div className="admin-actions">{items.map(x=><button key={x} onClick={()=>open("platform-config")}><b>{x}</b><span>View, configure and audit</span></button>)}</div></section>}<section className="card"><p className="eyebrow">Responsible operations</p><h2>Current safeguards</h2>{["Tenant isolation","Identifiable-data restriction","Prompt versioning","Support-access expiry","Audit logging"].map(x=><div className="list-item" key={x}><b>{x}</b><span className="status success">Active</span></div>)}</section></div></>;
}

function AppDialog({type,close,open,state,setState,selected,update,notify,resetDemo,openAssessment}:any){
  const title=type.split(":")[0]; const id=type.split(":").slice(1).join(":"); const user=state.users.find((u:any)=>u.id===id);
  const done=(message:string)=>{notify(message);close()};
  return <div className="modal-backdrop" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)close()}}><section className="modal functional-modal" role="dialog" aria-modal="true" aria-label={dialogTitle(title)}><button className="modal-close" onClick={close} aria-label="Close">×</button>
    {title==="create-assessment"&&<CreateAssessment state={state} setState={setState} done={(id:string)=>{openAssessment(id,"Work");done("Assessment saved and added to Work")}}/>}
    {title==="upload"&&selected&&<UploadDialogV2 assessment={selected} update={update} done={()=>done("Evidence uploaded and classified. OCR is ready.")}/>}
    {title==="grade-picker"&&<GradeSelectionDialog assessment={selected} open={open} done={done}/>}
    {title==="grade-file"&&<PerFileGradeDialog assessment={selected} file={(selected.files||[]).find((f:UploadFile)=>f.id===id)} state={state} setState={setState} update={update} open={open} notify={notify}/>}
    {title==="student-gaps"&&<StudentGapsDialog assessment={selected} fileId={id} open={open}/>}
    {title==="worksheet-gap"&&<WorksheetDialog state={state} setState={setState} sourceAssessment={selected} sourceResult={selected.gradeResults?.[id]} presetConcept={selected.gradeResults?.[id]?.gaps.slice().sort((a:Gap,b:Gap)=>a.mastery-b.mastery)[0]?.concept} presetTitle={selected.gradeResults?.[id]?`${selected.gradeResults[id].gaps.slice().sort((a:Gap,b:Gap)=>a.mastery-b.mastery)[0]?.concept} Practice`:undefined} presetStudent={selected.gradeResults?.[id]?.studentName} done={()=>done("Practice worksheet and answer key ready in Resources")}/>}
    {title==="setup"&&<SetupDialog assessment={selected} update={update} done={()=>done("Questions, answer key and rubric saved")}/>}
    {title==="process"&&<ProcessDialog assessment={selected} update={update} open={open} done={()=>{openAssessment(selected.id,"Review");done(`${selected.subject} answer sheets graded. Review this assessment now.`)}}/>}
    {title==="approval"&&<ConfirmDialog eyebrow="Teacher authority" title="Final approval" text={`${selected.reviewed}/${selected.totalReviews} answers reviewed. Approving locks grading version ${selected.version} and makes results ready to publish.`} action="Approve final grades" onConfirm={()=>{update(selected.id,{stage:"xray"});done("Final grades approved. Learning X-Ray generated.")}}/>}
    {title==="publish"&&<ConfirmDialog eyebrow="High-impact action" title="Publish grades" text="Published grades become visible in reports. A new version is required for later changes." action="Publish grades" onConfirm={()=>{update(selected.id,{stage:"published",published:true});done("Grades published and reports updated.")}}/>}
    {title==="regrade"&&<RegradeDialog assessment={selected} update={update} done={()=>done("Regrade version created and returned to teacher review")}/>}
    {title==="bulk-review"&&<BulkReview assessment={selected} update={update} done={()=>done("High-confidence answers approved in bulk")}/>}
    {title==="intervention-form"&&<InterventionForm state={state} setState={setState} assessment={selected} done={()=>done("Intervention created and added to the improvement cycle")}/>}
    {title==="study-guide"&&<StudyGuideDialog assessment={selected} fileId={id||undefined} open={open} setState={setState} done={()=>done("Study guide saved to resources")}/>}
    {(title==="worksheet"||title==="worksheet-edit")&&<WorksheetDialog state={state} setState={setState} sourceAssessment={selected} worksheet={state.resources.find((r:Worksheet)=>r.id===id)} done={()=>done("Worksheet saved to Resources with its answer key")}/>}
    {title==="worksheet-grade"&&<WorksheetGradingDialog worksheet={state.resources.find((r:Worksheet)=>r.id===id)} setState={setState} done={()=>done("Answer worksheets graded and results saved")}/>}
    {title==="followup"&&<FollowupDialog setState={setState} intervention={state.interventions.find((i:Intervention)=>i.id===id)} done={()=>done("Follow-up evidence recorded.")}/>}
    {title==="quality"&&<QualityDialog assessment={selected} state={state} done={()=>done("Assessment quality recommendations acknowledged")}/>}
    {title==="evidence"&&<EvidenceDialog state={state} id={id} done={()=>done("Evidence decision saved")}/>}
    {title==="report"&&<ReportDialog done={()=>done("Interactive report generated and saved")}/>}
    {title==="share-report"&&<ShareDialog done={()=>done("Secure demo link created with expiry and access code")}/>}
    {title==="invite"&&<InviteDialog state={state} setState={setState} done={()=>done("Invitation created and shown in Users")}/>}
    {title==="edit-user"&&user&&<UserEdit user={user} setState={setState} done={()=>done("User details updated")}/>}
    {title==="reset-user"&&user&&<ConfirmDialog eyebrow="Account security" title="Reset password" text={`Send a password-reset link to ${user.email}?`} action="Send reset link" onConfirm={()=>done("Password reset link sent")}/>}
    {title==="class"&&<ClassDialog state={state} setState={setState} done={()=>done("Class saved")}/>}
    {title==="school"&&<SchoolDialog state={state} setState={setState} done={()=>done("School profile saved")}/>}
    {title==="privacy-settings"&&<SimpleSettings title="Privacy & retention" fields={["Retention period","Support access","Login provider policy","Notification frequency"]} done={()=>done("Privacy and retention settings saved")}/>}
    {title==="platform-config"&&<SimpleSettings title="Platform configuration" fields={["Configuration area","Enabled status","Scope","Approval note"]} done={()=>done("Platform configuration version saved")}/>}
    {title==="profile"&&<SimpleSettings title="Profile & preferences" fields={["Display name","Mobile number","Preferred language","Email notifications"]} done={()=>done("Profile saved")}/>}
    {title==="activity"&&<Activity events={state.events} resetDemo={resetDemo} close={close}/>}
    {title==="notifications"&&<NotificationDialog state={state} done={()=>done("Notifications marked as read")}/>}
    {title==="group"&&<GroupDialog state={state} id={id} done={()=>done("Temporary group membership saved")}/>}
    {title==="student"&&<StudentDialog state={state} setState={setState} done={()=>done("Student added to the roster")}/>}
    {title==="import-students"&&<RosterImport state={state} setState={setState} done={()=>done("Student roster imported and validated")}/>}
    {title==="student-evidence"&&<StudentEvidence state={state} student={state.students.find((s:any)=>s.id===id)} done={()=>done("Student observation saved")}/>}
    {title==="academic-year"&&<AcademicYearDialog state={state} setState={setState} done={()=>done("Academic year saved")}/>}
    {title==="grading-settings"&&<SimpleSettings title="Grading preferences" fields={["Strictness","Partial-credit policy","Spelling and grammar tolerance","Working and units required","Alternative methods","Confidence threshold"]} done={()=>done("Grading preferences saved")}/>}
    {title==="appearance-settings"&&<SimpleSettings title="Appearance & accessibility" fields={["Appearance","High contrast","Text size","Reduced motion"]} done={()=>done("Accessibility preferences saved")}/>}
    {title==="notification-settings"&&<SimpleSettings title="Notification settings" fields={["Reminder frequency","Processing results","Intervention reminders","Follow-up reminders"]} done={()=>done("Notification settings saved")}/>}
    {title==="consent-settings"&&<ConsentDialog done={()=>done("Privacy and consent choices saved")}/>}
    {title==="security-settings"&&<SecurityDialog done={()=>done("Security preference saved")}/>}
    {title==="support-access"&&<SimpleSettings title="Temporary support access" fields={["Named support agent","Reason","Expiry","School approval"]} done={()=>done("Support-access decision saved and audited")}/>}
    {title==="report-settings"&&<SimpleSettings title="Report settings" fields={["Default expiry","Require OTP","Allow download","School branding"]} done={()=>done("Report defaults saved")}/>}
    {title==="review-help"&&<ConfirmDialog eyebrow="Workflow guide" title="Teacher review" text="Open the Review module to approve, edit, bulk-review, escalate or request a second AI opinion for every answer." action="Got it" onConfirm={close}/>}
    {title==="xray-details"&&<ConfirmDialog eyebrow="Learning X-Ray" title="Analysis ready" text="Open X-Ray to inspect student evidence, confidence, mastery and concept classifications." action="Got it" onConfirm={close}/>}
  </section></div>;
}

function CreateAssessment({state,setState,done}:any){
  const [error,setError]=useState(""),[saving,setSaving]=useState(false);
  const [sourceMode,setSourceMode]=useState<"upload"|"generate">("upload");
  const submit=async(e:FormEvent<HTMLFormElement>)=>{
    e.preventDefault();setError("");
    const f=new FormData(e.currentTarget);
    const references:{file:File;role:DocumentRole}[]=[];
    const title=String(f.get("title")),className=String(f.get("className")),subject=String(f.get("subject")),maxMarks=Number(f.get("marks"));
    setSaving(true);
    try{
      let questionCount=0,answerKey="",rubric="";
      if(sourceMode==="upload"){
        const questionPaper=f.get("questionPaper");const markingScheme=f.get("markingScheme");const modelAnswer=f.get("modelAnswer");
        if(!(questionPaper instanceof File)||!questionPaper.size)throw new Error("A question paper is required before the assessment can be created.");
        references.push({file:questionPaper,role:"Question paper"});
        if(markingScheme instanceof File&&markingScheme.size)references.push({file:markingScheme,role:"Marking scheme"});
        if(modelAnswer instanceof File&&modelAnswer.size)references.push({file:modelAnswer,role:"Model answer"});
      }else{
        const blueprint=f.get("blueprint");
        if(blueprint instanceof File&&blueprint.size&&!supportsDocumentUpload(blueprint))throw new Error(`${blueprint.name}: unsupported blueprint format.`);
        const blueprintPayload=blueprint instanceof File&&blueprint.size?{name:blueprint.name,mimeType:blueprint.type||"application/octet-stream",base64:await blobToBase64(blueprint)}:undefined;
        const response=await authFetch("/api/generate-assessment",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title,type:String(f.get("type")),className,subject,maxMarks,blueprint:blueprintPayload})});
        const payload=await response.json();
        logApiTiming(setState,payload?.timing);
        if(!response.ok)throw new Error(payload?.error||"Assessment generation failed.");
        questionCount=Math.max(1,Number(payload.questionCount)||1);answerKey=String(payload.modelAnswerText||"");rubric=String(payload.markingSchemeText||"");
        const safeTitle=title.replace(/[^a-z0-9-]+/gi,"-");
        const documentMeta=`Class ${className} · ${subject} · ${title}`;
        const [questionPaperPdf,markingSchemePdf,modelAnswerPdf]=await Promise.all([
          createBrandedPdfBlob(`${title} · Question Paper`,documentMeta,textToDocumentHtml(String(payload.questionPaperText))),
          createBrandedPdfBlob(`${title} · Marking Scheme`,documentMeta,textToDocumentHtml(String(payload.markingSchemeText))),
          createBrandedPdfBlob(`${title} · Model Answer`,documentMeta,textToDocumentHtml(String(payload.modelAnswerText))),
        ]);
        references.push(
          {file:new File([questionPaperPdf],`${safeTitle}-Question-Paper.pdf`,{type:"application/pdf"}),role:"Question paper"},
          {file:new File([markingSchemePdf],`${safeTitle}-Marking-Scheme.pdf`,{type:"application/pdf"}),role:"Marking scheme"},
          {file:new File([modelAnswerPdf],`${safeTitle}-Model-Answer.pdf`,{type:"application/pdf"}),role:"Model answer"},
        );
        if(blueprint instanceof File&&blueprint.size)references.push({file:blueprint,role:"Supporting reference"});
      }
      if(references.some(item=>item.file.size>10*1024*1024))throw new Error("Each document must be 10 MB or smaller.");
      if(references.some(item=>!supportsDocumentUpload(item.file)))throw new Error("Use PDF, Word, Markdown, text, spreadsheet or supported image files.");
      const files:UploadFile[]=references.map(({file,role})=>({id:`f${crypto.randomUUID()}`,name:file.name,type:file.type||"application/pdf",size:file.size,progress:100,status:"OCR ready",documentRole:role}));
      await Promise.all(files.map((item,index)=>saveFileBlob(item.id,references[index].file)));
      const id=`a${Date.now()}`;
      const a:Assessment={id,title,type:String(f.get("type")),grade:className,section:String(f.get("section")),subject,maxMarks,date:String(f.get("date")),stage:"draft",files,questions:questionCount,reviewed:0,totalReviews:0,quality:0,published:false,version:1,answerKey,rubric};
      setState((s:DemoState)=>({...s,assessments:[a,...s.assessments],events:[`${sourceMode==="generate"?"Assessment generated":"Assessment created with uploaded reference documents"} · ${a.title}`,...s.events]}));
      done(id);
    }catch(err){setError(err instanceof Error?err.message:"Assessment could not be created.");setSaving(false)}
  };
  return <form onSubmit={submit}><DialogHead eyebrow="New work" title="Create or generate assessment"/><div className="form-grid"><Field label="Title"><input name="title" required minLength={3} placeholder="e.g. Fractions checkpoint"/></Field><Field label="Activity type"><select name="type" required>{["Test","Quiz","Worksheet","Homework","Assessment","Diagnostic","Follow-up"].map(x=><option key={x}>{x}</option>)}</select></Field><Field label="Class"><select name="className">{Array.from({length:12},(_,index)=>String(index+1)).map(x=><option key={x}>{x}</option>)}</select></Field><Field label="Section"><input name="section" required defaultValue="A"/></Field><Field label="Subject"><input name="subject" required defaultValue="Mathematics"/></Field><Field label="Maximum marks"><input name="marks" type="number" min="1" max="200" required defaultValue="20"/></Field><Field label="Assessment date"><input name="date" type="date" required defaultValue={new Date().toISOString().slice(0,10)}/></Field><Field label="Grading mode"><select><option>Structured</option><option>Objective</option><option>Rubric</option><option>Completion</option></select></Field></div><div className="assessment-source-picker" role="radiogroup" aria-label="Question paper source"><button type="button" role="radio" aria-checked={sourceMode==="upload"} className={sourceMode==="upload"?"active":""} onClick={()=>setSourceMode("upload")}><b>Upload question paper</b><small>Use an existing paper and optional marking references</small></button><button type="button" role="radio" aria-checked={sourceMode==="generate"} className={sourceMode==="generate"?"active":""} onClick={()=>setSourceMode("generate")}><b>Generate assessment</b><small>Create a paper, marking scheme and model answer with AI</small></button></div><section className="assessment-reference-files"><p className="eyebrow">{sourceMode==="upload"?"Assessment reference documents":"AI assessment generation"}</p>{sourceMode==="upload"?<><p className="modal-copy">The uploaded files are fixed to the assessment and automatically used during OCR and learning-gap analysis.</p><Field label="Question paper · required"><input name="questionPaper" type="file" accept={DOCUMENT_ACCEPT} required/></Field><div className="form-grid"><Field label="Marking scheme"><input name="markingScheme" type="file" accept={DOCUMENT_ACCEPT}/></Field><Field label="Model answer paper"><input name="modelAnswer" type="file" accept={DOCUMENT_ACCEPT}/></Field></div></>:<><p className="modal-copy">A blueprint is optional. When supplied, its structure, sections and mark distribution guide the generated assessment.</p><Field label="Assessment blueprint · optional"><input name="blueprint" type="file" accept={DOCUMENT_ACCEPT}/></Field><div className="insight">EduAI will generate the compulsory question paper together with its marking scheme and complete model answer. You can review the generated documents before analysing student work.</div></>}</section>{error&&<p className="form-error" role="alert">{error}</p>}<button className="primary full" disabled={saving}>{saving?(sourceMode==="generate"?"Generating assessment & references…":"Saving assessment & documents…"):(sourceMode==="generate"?"Generate & save assessment":"Save uploaded assessment")}</button></form>
}

function UploadDialog({assessment,update,done}:any){const input=useRef<HTMLInputElement>(null);const [files,setFiles]=useState<UploadFile[]>(assessment.files||[]);const [error,setError]=useState("");const add=(list:FileList|File[])=>{setError("");const next:Array<UploadFile>=[];Array.from(list).forEach(file=>{if(!supportsDocumentUpload(file)){setError(`${file.name}: unsupported format. Use PDF, Word, Markdown, text, spreadsheet or an image.`);return}if(file.size>10*1024*1024){setError(`${file.name}: exceeds the 10 MB limit.`);return}next.push({id:`f${Date.now()}${file.name}`,name:file.name,type:file.type||"application/octet-stream",size:file.size,progress:0,status:"Ready",preview:file.type.startsWith("image/")?URL.createObjectURL(file):undefined})});setFiles(x=>[...x,...next])};const upload=()=>{if(!files.length){setError("Choose at least one supported document or image.");return}let p=0;const timer=window.setInterval(()=>{p+=20;setFiles(fs=>fs.map(f=>({...f,progress:Math.min(100,p),status:p>=100?"Uploaded · ready for OCR":"Uploading"})));if(p>=100){clearInterval(timer);window.setTimeout(()=>{update(assessment.id,{files:files.map(f=>({...f,progress:100,status:"OCR complete",preview:undefined})),stage:"uploaded",totalReviews:Math.max(assessment.totalReviews,files.length*4)});done()},400)}},180)};return <><DialogHead eyebrow={assessment.title} title="Upload student work"/><div className="dropzone" role="button" tabIndex={0} onClick={()=>input.current?.click()} onKeyDown={e=>{if(e.key==="Enter"||e.key===" ")input.current?.click()}} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();add(e.dataTransfer.files)}}><span>↑</span><b>Drop files here or choose files</b><small>PDF, Word, Markdown, text, spreadsheet or image · multiple files · 10 MB each</small><button type="button" className="secondary" onClick={e=>{e.stopPropagation();input.current?.click()}}>Browse / Choose File</button><input ref={input} className="file-input" type="file" multiple accept={DOCUMENT_ACCEPT} onChange={e=>e.target.files&&add(e.target.files)}/></div>{error&&<p className="form-error" role="alert">{error}</p>}<div className="upload-list">{files.map(f=><div key={f.id}>{f.preview?<img src={f.preview} alt={`Preview ${f.name}`}/>:<span className="file-icon">{f.name.split(".").pop()?.toUpperCase()}</span>}<div><b>{f.name}</b><small>{(f.size/1024/1024).toFixed(2)} MB · {f.status}</small><Progress value={f.progress}/></div><button onClick={()=>setFiles(x=>x.filter(v=>v.id!==f.id))} aria-label={`Remove ${f.name}`}>×</button></div>)}</div><button className="primary full" onClick={upload}>Upload and start OCR</button></>}

function SetupDialog({assessment,update,done}:any){
  const [questions,setQuestions]=useState(assessment.questions||5);
  const [answerKey,setAnswerKey]=useState(assessment.answerKey||"Q1: Equivalent fractions; Q2: Common denominator; Q3: Add numerators after conversion.");
  const [rubric,setRubric]=useState(assessment.rubric||"Method 40% · Conversion 30% · Calculation 20% · Final answer and unit 10%");
  return <form onSubmit={e=>{e.preventDefault();update(assessment.id,{questions,answerKey,rubric,stage:"setup"});done()}}><DialogHead eyebrow="Question detection" title="Review questions & rubric"/><p className="modal-copy">The simulation detected {questions} questions. Review the answer key and partial-credit rules before grading.</p><Field label="Detected questions"><input type="number" min="1" max="50" value={questions} onChange={e=>setQuestions(Number(e.target.value))}/></Field><Field label="Answer key / expected evidence"><textarea required value={answerKey} onChange={e=>setAnswerKey(e.target.value)}/></Field><div className="form-grid"><Field label="Strictness"><select><option>Balanced</option><option>Supportive</option><option>Strict</option></select></Field><Field label="Partial credit"><select><option>Allow method marks</option><option>Final answer only</option></select></Field></div><Field label="Rubric criteria"><textarea value={rubric} onChange={e=>setRubric(e.target.value)}/></Field><button className="primary full">Approve structure & rubric</button></form>}
function GradeSelectionDialog({assessment,open,done}:any){const allFiles:UploadFile[]=assessment.files||[];const answerCandidates:UploadFile[]=allFiles.filter((f:UploadFile)=>isAnswerSheetFile(f,allFiles.length));const hasQuestionPaper=allFiles.some((f:UploadFile)=>isQuestionPaperFile(f,allFiles.length));const preferred=answerCandidates[0];const [selectedFileId,setSelectedFileId]=useState(preferred?.id||"");return <><DialogHead eyebrow={assessment.title} title="Select answer sheet for analysis"/><p className="modal-copy">Choose the student answer sheet. The assessment question paper, marking scheme, and model answer are linked automatically.</p><div className="grade-file-picker">{allFiles.map((file:UploadFile)=>{const graded=Boolean(assessment.gradeResults?.[file.id]);const answer=isAnswerSheetFile(file,allFiles.length);return <label key={file.id} className={selectedFileId===file.id?"selected":""}><input type="radio" name="grade-file" value={file.id} disabled={!answer} checked={selectedFileId===file.id} onChange={()=>setSelectedFileId(file.id)}/><span className="file-icon">{file.name.split(".").pop()?.toUpperCase()}</span><span><b>{file.name}</b><small>{answer?"Answer sheet":`${file.documentRole||inferDocumentRole(file.name)} · assessment reference`}</small></span>{graded&&<em>Already analysed</em>}</label>})}</div>{!hasQuestionPaper&&<p className="form-error">A question paper is compulsory. This assessment cannot be analysed until one is attached in assessment creation.</p>}{!answerCandidates.length&&<p className="form-error">Upload at least one student answer sheet.</p>}<button className="primary full" disabled={!selectedFileId||!hasQuestionPaper} onClick={()=>open(`grade-file:${selectedFileId}`)}>Continue with this answer sheet →</button></>}
function ProcessDialog({assessment,update,open,done}:any){
  const files:UploadFile[]=(assessment.files||[]).filter((f:UploadFile)=>isAnswerSheetFile(f,(assessment.files||[]).length));
  const gradedCount=files.filter(f=>Boolean(assessment.gradeResults?.[f.id])).length;
  const allGraded=files.length>0&&gradedCount===files.length;
  const continueToReview=()=>{update(assessment.id,{stage:"review",reviewed:assessment.reviewed,totalReviews:Math.max(assessment.totalReviews,files.length*4)});done()};
  return <><DialogHead eyebrow="Grading status" title="OCR & grading pipeline"/><p className="modal-copy">Each answer sheet is graded individually with OCR and diagnostic learning analysis. Grade every file below, then continue to teacher review.</p>
  <div className="upload-list">{files.map(f=>{const graded=Boolean(assessment.gradeResults?.[f.id]);return <div key={f.id}><span className="file-icon">{f.name.split(".").pop()?.toUpperCase()}</span><div><b>{f.name}</b><small>{graded?"Graded":"Not graded yet"}</small></div>{!graded&&<button className="secondary" onClick={()=>open(`grade-file:${f.id}`)}>Grade now</button>}</div>})}</div>
  {!files.length&&<p className="form-error">No answer-sheet files uploaded yet.</p>}
  <button className="primary full" disabled={!allGraded} onClick={continueToReview}>{allGraded?"Continue to teacher review":`${gradedCount}/${files.length} graded — grade all files to continue`}</button></>}
function RegradeDialog({assessment,update,done}:any){
  const affected=Object.keys(assessment.gradeResults||{}).length;
  const submit=(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();update(assessment.id,{stage:"review",reviewed:0,version:assessment.version+1});done()};
  return <form onSubmit={submit}><DialogHead eyebrow="Versioned grading" title="Start regrade"/><Field label="Scope"><select required><option>Selected question</option><option>Selected students</option><option>Full assessment</option><option>Rubric criterion</option></select></Field><Field label="Reason"><select required><option>Alternative correct answer discovered</option><option>Rubric changed</option><option>Partial-credit rule changed</option><option>Question ambiguity</option><option>Moderation</option></select></Field><Field label="Teacher note"><textarea required placeholder="Explain the change for the audit history"/></Field><div className="impact-box"><b>Impact preview</b><span>{affected} student{affected===1?"":"s"} with existing graded evidence. Score changes will be calculated after the regrade runs.</span></div><button className="primary full">Confirm regrade version {assessment.version+1}</button></form>}
function BulkReview({assessment,update,done}:any){
  const remaining=Math.max(0,assessment.totalReviews-assessment.reviewed);
  return <><DialogHead eyebrow="High-confidence objective answers" title="Bulk review"/><p className="modal-copy">{remaining} answer{remaining===1?"":"s"} remain in the review queue for this assessment.</p><div className="list-item"><b>Approve {remaining} remaining answer{remaining===1?"":"s"}</b></div><button className="primary full" disabled={!remaining} onClick={()=>{update(assessment.id,{reviewed:assessment.totalReviews});done()}}>Approve remaining answers</button></>}
function InterventionForm({state,setState,assessment,done}:any){
  const results:GradeResult[]=Object.values(assessment.gradeResults||{});
  const conceptAgg:Record<string,{sum:number;count:number}>={};
  results.forEach(r=>r.gaps.forEach(g=>{const b=conceptAgg[g.concept]||{sum:0,count:0};b.sum+=g.mastery;b.count+=1;conceptAgg[g.concept]=b}));
  const sortedConcepts=Object.entries(conceptAgg).map(([concept,b])=>({concept,mastery:b.sum/b.count})).sort((a,b)=>a.mastery-b.mastery);
  const defaultConcept=sortedConcepts[0]?.concept||"";
  const submit=(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();const f=new FormData(e.currentTarget);const i:Intervention={id:`i${Date.now()}`,assessmentId:assessment.id,concept:String(f.get("concept")),format:String(f.get("format")),duration:String(f.get("duration")),status:"Planned",followup:String(f.get("followup"))};setState((s:DemoState)=>({...s,interventions:[i,...s.interventions],assessments:s.assessments.map(a=>a.id===assessment.id?{...a,stage:"intervention"}:a),events:[`Intervention created · ${i.concept}`,...s.events]}));done()};
  return <form onSubmit={submit}><DialogHead eyebrow="Plan intervention" title="Plan intervention"/><Field label="Concept"><input name="concept" required defaultValue={defaultConcept} placeholder="Grade an answer sheet first to prefill the priority gap"/></Field><div className="form-grid"><Field label="Format"><select name="format"><option>5-minute correction</option><option>Guided practice</option><option>Full-period reteaching</option><option>Homework</option><option>Remedial support</option><option>Exit ticket</option></select></Field><Field label="Duration"><select name="duration"><option>15 minutes</option><option>5 minutes</option><option>40 minutes</option></select></Field><Field label="Group"><select><option>Strengthen</option><option>Practise</option><option>Extend</option></select></Field><Field label="Follow-up date"><input name="followup" type="date" required defaultValue={new Date(Date.now()+7*86400000).toISOString().slice(0,10)}/></Field></div><Field label="Objective & activity"><textarea required placeholder="Describe the teaching activity for this concept"/></Field><button className="primary full">Approve and create plan</button></form>}
function StudyGuideDialog({assessment,fileId,open,setState,done}:any){
  const result:GradeResult|undefined=fileId?assessment.gradeResults?.[fileId]:undefined;
  const gap=result?.gaps.slice().sort((a,b)=>a.mastery-b.mastery)[0];
  const [generating,setGenerating]=useState(false);
  const [progress,setProgress]=useState(0);
  const [guide,setGuide]=useState<any>(null);
  const [error,setError]=useState("");
  if(!gap){
    return <><DialogHead eyebrow={assessment.title} title="Targeted study guide"/><p className="modal-copy">No graded evidence is available yet for {assessment.subject}. Grade at least one answer sheet first so the study guide can target a real learning gap instead of placeholder content.</p></>;
  }
  const concept=gap.concept;
  const generate=async()=>{
    setGenerating(true);setError("");setProgress(5);
    const started=Date.now();const progressTimer=window.setInterval(()=>setProgress(Math.min(92,8+Math.round((Date.now()-started)/500))),1000);
    try{
      const response=await authFetch("/api/generate-study-guide",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({subject:assessment.subject,concept,studentName:result?.studentName,mastery:gap.mastery,gaps:result?.gaps,feedback:result?.feedback,ocrText:result?.ocrText,evidenceFiles:assessment.files.map((file:UploadFile)=>`${file.documentRole||inferDocumentRole(file.name)}: ${file.name}`)})});
      const payload=await response.json();
      if(!response.ok)throw new Error(payload?.error||"Study-guide generation failed");
      setProgress(100);
      setGuide(payload.guide);
      const saved:Worksheet={id:`guide-${assessment.id}-${fileId}`,title:payload.guide.title,type:"Study Guide",status:"Saved",subject:assessment.subject,grade:assessment.grade,assessmentId:assessment.id,concepts:(result?.gaps||[]).map((g:Gap)=>g.concept),guide:payload.guide,studentName:result?.studentName};
      setState((s:DemoState)=>({...s,resources:[saved,...s.resources.filter(r=>r.id!==saved.id)],events:[`Study guide saved · ${saved.title}`,...s.events]}));
    }catch(err){setError(err instanceof Error?err.message:"Study-guide generation failed")}finally{clearInterval(progressTimer);setGenerating(false)}
  };
  const download=()=>downloadStudyGuide({title:guide.title,subject:assessment.subject,grade:assessment.grade,studentName:result?.studentName},guide);
  return <><DialogHead eyebrow={`${result?`${result.studentName} · `:""}Learning recovery plan · ${assessment.title}`} title="Complete study guide"/>
    <p className="modal-copy">This guide covers all <b>{result?.gaps.length||1} diagnosed learning gap{result?.gaps.length===1?"":"s"}</b>, beginning with the weakest topic. Every section is grounded in the uploaded evidence and diagnostic findings.</p>
    {!guide&&<button className="secondary full" disabled={generating} onClick={generate}>{generating?"Generating evidence-based guide…":"Generate and save study guide"}</button>}
    {generating&&<><Progress value={progress}/><p className="modal-copy">Server generation in progress · {progress}% · safe to switch tabs</p></>}
    {error&&<p className="form-error" role="alert">{error}</p>}
    {guide&&<><div className="branded-document study-guide-view"><BrandDocumentHeader label="Personalised study guide" title={guide.title} meta={`${assessment.subject} · ${result?.studentName||"Student"} · ${guide.topics?.length||0} topic plan`}/><p className="guide-overview">{guide.overview}</p><nav className="guide-topic-index" aria-label="Study guide topics">{(guide.topics||[]).map((topic:any,index:number)=><span key={topic.concept}><b>{index+1}</b>{topic.concept}<small>{topic.mastery}% starting mastery</small></span>)}</nav><div className="source-ribbon"><b>Built from</b>{assessment.files.map((file:UploadFile)=><span key={file.id}>{file.documentRole||inferDocumentRole(file.name)} · {file.name}</span>)}</div><div className="guide-topic-sections">{(guide.topics||[]).map((topic:any,index:number)=><section key={topic.concept}><header><span>Topic {index+1}</span><h3>{topic.concept}</h3><b>{topic.mastery}%</b></header><div className="diagnosis-callout"><b>Why this is a learning gap</b><p>{topic.diagnosis}</p></div><div className="guide-learning-grid"><article><b>Learning objective</b><p>{topic.learningObjective}</p></article><article><b>Clear explanation</b><p>{topic.explanation}</p></article><article className="span-2"><b>Worked example</b><p>{topic.workedExample}</p></article><article><b>Guided practice</b><ol>{(topic.practiceSteps||[]).map((step:string,i:number)=><li key={i}>{step}</li>)}</ol></article><article><b>Check for understanding</b><ol>{(topic.checkForUnderstanding||[]).map((step:string,i:number)=><li key={i}>{step}</li>)}</ol></article></div></section>)}</div></div>
    <Field label="Teacher instructions"><textarea defaultValue={`Use this ${assessment.subject} guide to address ${concept}. Ask the student to explain the evidence behind each response.`}/></Field>
    <div className="button-row">
      <button className="secondary" onClick={download}>Download branded PDF study guide</button>
      <button className="secondary" onClick={generate} disabled={generating}>Regenerate</button>
      {fileId?<button className="primary" onClick={()=>open(`worksheet-gap:${fileId}`)}>Continue to practice worksheet →</button>:<button className="primary" onClick={done}>Approve & save</button>}
    </div></>}
  </>
}

function PerFileGradeDialog({assessment,file,state,setState,update,open,notify}:any){
  if(!file)return <><DialogHead eyebrow={assessment.title} title="Grade answer sheet"/><p className="modal-copy">This answer sheet could not be found. Close this dialog and try again.</p></>;
  const candidates:UploadFile[]=(assessment.files||[]).filter((f:UploadFile)=>f.id!==file.id);
  const questionPapers=candidates.filter(f=>f.documentRole==="Question paper"||(!f.documentRole&&/question|paper|qp/i.test(f.name)));
  const markingSchemes=candidates.filter(f=>f.documentRole==="Marking scheme"||(!f.documentRole&&/marking.?scheme|mark.?scheme/i.test(f.name)));
  const modelAnswers=candidates.filter(f=>f.documentRole==="Model answer"||(!f.documentRole&&/answer.?key|model.?answer|solutions?/i.test(f.name)));
  const otherQuestionPaperChoices=candidates.filter(f=>!questionPapers.some(q=>q.id===f.id));
  const preferredQP=questionPapers[0];
  const preferredScheme=markingSchemes[0];
  const preferredModel=modelAnswers[0];
  const mappingOptions=classSubjectOptions(state);
  const initialClassKey=assessment.grade&&assessment.section?`${assessment.grade}|${assessment.section.toUpperCase()}`:mappingOptions[0]?.classKey||"";
  const [qpId,setQpId]=useState(preferredQP?.id||"");
  const [markingSchemeId,setMarkingSchemeId]=useState(preferredScheme?.id||"");
  const [modelAnswerId,setModelAnswerId]=useState(preferredModel?.id||"");
  const [studentName,setStudentName]=useState(()=>guessStudentName(file,state.students));
  const [analysisClassKey,setAnalysisClassKey]=useState(initialClassKey);
  const availableSubjects=Array.from(new Set(mappingOptions.filter(option=>option.classKey===analysisClassKey).map(option=>option.subject)));
  const [analysisSubject,setAnalysisSubject]=useState(()=>availableSubjects.includes(assessment.subject)?assessment.subject:availableSubjects[0]||"");
  const selectedMapping=mappingOptions.find(option=>option.classKey===analysisClassKey&&option.subject===analysisSubject);
  const analysisGrade=selectedMapping?`Class ${selectedMapping.grade}${selectedMapping.section}`:"";
  const [progress,setProgress]=useState(0);
  const [running,setRunning]=useState(false);
  const [ocrDocuments,setOcrDocuments]=useState<any>(null);
  const alreadyGraded=Boolean(assessment.gradeResults?.[file.id]);
  const [reanalysisReason,setReanalysisReason]=useState("");
  const [gradeError,setGradeError]=useState("");
  const resetReferenceOcr=()=>{setOcrDocuments(null);setProgress(0);setGradeError("")};
  const changeQuestionPaper=(id:string)=>{setQpId(id);resetReferenceOcr()};
  const grade=async()=>{
    if(!studentName.trim()){notify("Enter the student's name before grading.","warning");return}
    if(!qpId){notify("A question paper is compulsory before learning-gap analysis can start.","warning");return}
    if(!analysisSubject.trim()||!analysisGrade.trim()){notify("Subject and Class are required before generating learning gaps.","warning");return}
    if(alreadyGraded&&!reanalysisReason.trim()){notify("Enter a Reason for Reanalysis before starting.","warning");return}
    const validatedOcr=[ocrDocuments?.answerSheet?.text||"",ocrDocuments?.questionPaper?.text||"",ocrDocuments?.markingScheme?.text||"",ocrDocuments?.modelAnswer?.text||""].join("|");
    let ocrHash=0;for(let i=0;i<validatedOcr.length;i++)ocrHash=((ocrHash<<5)-ocrHash+validatedOcr.charCodeAt(i))|0;
    const evidenceFingerprint=[file.id,qpId,markingSchemeId,modelAnswerId,assessment.answerKey||"",assessment.rubric||"",analysisSubject,analysisGrade,ocrHash,alreadyGraded?reanalysisReason.trim():""].join("|");
    const previous:GradeResult|undefined=assessment.gradeResults?.[file.id];
    if(ocrDocuments&&previous?.evidenceFingerprint===evidenceFingerprint){
      notify(`This evidence has not changed. The fixed score and learning gaps for ${previous.studentName} were reused.`);
      open(`student-gaps:${file.id}`);
      return;
    }
    setGradeError("");setRunning(true);let p=0;
    const timer=window.setInterval(()=>{p=Math.min(90,p+15);setProgress(p)},180);
    try{
      const blob=await readFileBlob(file.id);
      if(!blob)throw new Error("This file's data could not be found in local storage. Try re-uploading it.");
      const fileBase64=await blobToBase64(blob);
      const qp=candidates.find(f=>f.id===qpId);
      const qpBlob=qpId?await readFileBlob(qpId):null;
      const markingSchemeFile=candidates.find(f=>f.id===markingSchemeId);
      const markingSchemeBlob=markingSchemeId?await readFileBlob(markingSchemeId):null;
      const modelAnswerFile=candidates.find(f=>f.id===modelAnswerId);
      const modelAnswerBlob=modelAnswerId?await readFileBlob(modelAnswerId):null;
      if(qpId&&!qp)throw new Error("The selected question paper is no longer in Uploaded evidence. Select it again.");
      if(qpId&&!qpBlob)throw new Error("The selected question paper could not be loaded. Preview it in Uploaded evidence or re-upload it.");
      if(markingSchemeId&&!markingSchemeBlob)throw new Error("The assessment marking scheme could not be loaded.");
      if(modelAnswerId&&!modelAnswerBlob)throw new Error("The assessment model answer could not be loaded.");
      if(!ocrDocuments){
        const documents=[
          {id:"answerSheet",name:file.name,base64:fileBase64,mimeType:file.type||"application/pdf"},
          {id:"questionPaper",name:qp?.name||"Question paper",base64:await blobToBase64(qpBlob as Blob),mimeType:qp?.type||"application/pdf"},
          ...(markingSchemeBlob?[{id:"markingScheme",name:markingSchemeFile?.name||"Marking scheme",base64:await blobToBase64(markingSchemeBlob),mimeType:markingSchemeFile?.type||"application/pdf"}]:[]),
          ...(modelAnswerBlob?[{id:"modelAnswer",name:modelAnswerFile?.name||"Model answer",base64:await blobToBase64(modelAnswerBlob),mimeType:modelAnswerFile?.type||"application/pdf"}]:[])
        ];
        const ocrResponse=await authFetch("/api/ocr",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({documents})});
        const ocrPayload=await ocrResponse.json();
        logApiTiming(setState,ocrPayload?.timing);
        if(!ocrResponse.ok)throw new Error(ocrPayload?.error||"OCR request failed");
        const cleanDocuments=Object.fromEntries(Object.entries(ocrPayload.documents||{}).map(([id,document]:any)=>[id,{...document,text:normalizeOcrText(document?.text||"")}]));
        clearInterval(timer);setProgress(100);setOcrDocuments(cleanDocuments);
        notify("Mistral OCR is complete. Review and correct the extracted text before validation.");
        return;
      }
      const concepts=gapConceptsFor(assessment.subject);
      const res=await authFetch("/api/grade",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          subject:analysisSubject,
          className:analysisGrade,
          studentName:studentName.trim(),
          fileName:file.name,
          documentRole:file.documentRole||inferDocumentRole(file.name),
          maxMarks:assessment.maxMarks,
          answerKey:assessment.answerKey,
          rubric:assessment.rubric,
          ocrText:ocrDocuments.answerSheet?.text,
          questionPaperText:ocrDocuments.questionPaper?.text,
          questionPaperName:qp?.name,
          markingSchemeText:ocrDocuments.markingScheme?.text,
          markingSchemeName:markingSchemeFile?.name,
          modelAnswerText:ocrDocuments.modelAnswer?.text,
          modelAnswerName:modelAnswerFile?.name,
          reanalysisReason:alreadyGraded?reanalysisReason.trim():undefined
        })
      });
      const payload=await res.json();
      logApiTiming(setState,payload?.timing);
      if(!res.ok)throw new Error(payload?.error||"Grading request failed");
      clearInterval(timer);setProgress(100);
      const gaps:Gap[]=(payload.gaps||[]).map((g:any)=>({concept:String(g.concept),mastery:Math.max(0,Math.min(100,Math.round(Number(g.mastery)))),finding:String(g.finding||""),misconception:String(g.misconception||""),evidence:String(g.evidence||""),rework:String(g.rework||""),severity:["priority","developing","secure"].includes(g.severity)?g.severity:undefined})).sort((a:Gap,b:Gap)=>a.mastery-b.mastery);
      const detectedMaxMarks=Math.max(1,Math.round(Number(payload.maxMarks)||assessment.maxMarks));
      const score=Math.max(0,Math.min(detectedMaxMarks,Math.round(Number(payload.score))));
      const result:GradeResult={fileId:file.id,studentName:studentName.trim(),questionPaperFileId:qpId||undefined,questionPaperName:qp?.name,score,maxMarks:detectedMaxMarks,gaps,date:new Date().toISOString(),feedback:typeof payload.feedback==="string"?payload.feedback:undefined,ocrText:ocrDocuments.answerSheet?.text,evidenceFingerprint,reanalysisReason:alreadyGraded?reanalysisReason.trim():undefined};
      update(assessment.id,{
        grade:selectedMapping?.grade||assessment.grade,
        section:selectedMapping?.section||assessment.section,
        subject:analysisSubject,
        maxMarks:detectedMaxMarks,
        gradeResults:{...(assessment.gradeResults||{}),[file.id]:result},
        gradedFileIds:Array.from(new Set([...(assessment.gradedFileIds||[]),file.id])),
        lastGradedFileId:file.id,
        stage:["draft","uploaded","setup"].includes(assessment.stage)?"review":assessment.stage
      });
      notify(`${result.studentName}'s validated OCR was analysed. The report includes only wrong, partial and unanswered questions.`);
      window.setTimeout(()=>open(`student-gaps:${file.id}`),300);
    }catch(err){
      clearInterval(timer);
      const message=err instanceof Error?err.message:"Grading failed";
      setGradeError(message);
      notify(`Grading failed: ${message}`,"error");
    }finally{
      setRunning(false);
    }
  };
  const updateOcr=(id:string,text:string)=>setOcrDocuments((current:any)=>({...current,[id]:{...current[id],text}}));
  return <><DialogHead eyebrow={assessment.title} title={alreadyGraded?"Regrade answer sheet":"Grade answer sheet"}/>
    <p className="modal-copy">First extract text with Mistral. Review and correct it on screen. Learning-gap analysis will not start until you validate the OCR text.</p>
    <Field label="Answer sheet"><input value={file.name} disabled/></Field>
    <Field label="Student name"><input value={studentName} onChange={e=>setStudentName(e.target.value)} required/></Field>
    <div className="form-grid">
      <Field label="Class & section"><select value={analysisClassKey} onChange={e=>{const nextClass=e.target.value;const nextSubject=mappingOptions.find(option=>option.classKey===nextClass)?.subject||"";setAnalysisClassKey(nextClass);setAnalysisSubject(nextSubject)}} required><option value="" disabled>Select class & section</option>{Array.from(new Map(mappingOptions.map(option=>[option.classKey,option])).values()).map(option=><option key={option.classKey} value={option.classKey}>Class {option.grade}{option.section}</option>)}</select></Field>
      <Field label="Subject"><select value={analysisSubject} onChange={e=>setAnalysisSubject(e.target.value)} required disabled={!availableSubjects.length}><option value="" disabled>Select subject</option>{availableSubjects.map(item=><option key={item}>{item}</option>)}</select></Field>
    </div>
    {alreadyGraded&&<Field label="Reason for Reanalysis"><textarea value={reanalysisReason} onChange={e=>setReanalysisReason(e.target.value)} required rows={4} placeholder="Explain what the previous analysis missed or should reconsider."/></Field>}
    <Field label="Question paper · required">
      <select value={qpId} onChange={e=>changeQuestionPaper(e.target.value)}>
        <option value="">Select the assessment question paper</option>
        {questionPapers.length>0&&<optgroup label="Assessment question papers">{questionPapers.map(f=><option key={f.id} value={f.id}>{f.name}</option>)}</optgroup>}
        {otherQuestionPaperChoices.length>0&&<optgroup label="Legacy uploaded evidence">{otherQuestionPaperChoices.map(f=><option key={f.id} value={f.id}>{f.name} · {f.documentRole||inferDocumentRole(f.name)}</option>)}</optgroup>}
      </select>
    </Field>
    <div className="form-grid"><Field label="Marking scheme"><select value={markingSchemeId} onChange={e=>{setMarkingSchemeId(e.target.value);resetReferenceOcr()}}><option value="">Not supplied</option>{markingSchemes.map(f=><option key={f.id} value={f.id}>{f.name}</option>)}</select></Field><Field label="Model answer paper"><select value={modelAnswerId} onChange={e=>{setModelAnswerId(e.target.value);resetReferenceOcr()}}><option value="">Not supplied</option>{modelAnswers.map(f=><option key={f.id} value={f.id}>{f.name}</option>)}</select></Field></div>
    {!questionPapers.length&&<p className="form-error">This legacy assessment has no question paper. Edit or recreate the assessment with the compulsory question paper before analysis.</p>}
    {ocrDocuments&&<section className="ocr-validation"><header><div><p className="eyebrow">OCR validation</p><h3>Check the extracted text</h3></div><span className="status warning">Teacher validation required</span></header><p>Correct names, question numbers, marks, formulas or unreadable words before continuing.</p><label><b>Student answer sheet · {ocrDocuments.answerSheet?.name}</b><textarea value={ocrDocuments.answerSheet?.text||""} onChange={e=>updateOcr("answerSheet",e.target.value)} rows={12}/></label>{ocrDocuments.questionPaper&&<label><b>Question paper · {ocrDocuments.questionPaper.name}</b><textarea value={ocrDocuments.questionPaper.text} onChange={e=>updateOcr("questionPaper",e.target.value)} rows={8}/></label>}{ocrDocuments.markingScheme&&<label><b>Marking scheme · {ocrDocuments.markingScheme.name}</b><textarea value={ocrDocuments.markingScheme.text} onChange={e=>updateOcr("markingScheme",e.target.value)} rows={8}/></label>}{ocrDocuments.modelAnswer&&<label><b>Model answer paper · {ocrDocuments.modelAnswer.name}</b><textarea value={ocrDocuments.modelAnswer.text} onChange={e=>updateOcr("modelAnswer",e.target.value)} rows={8}/></label>}</section>}
    {progress>0&&<><Progress value={progress}/><p className="modal-copy">{running?(ocrDocuments?`Diagnostic analysis: ${progress}%`:`Mistral OCR: ${progress}%`):ocrDocuments?"OCR complete · awaiting teacher validation":"Ready"}</p></>}
    {gradeError&&<p className="form-error" role="alert">{gradeError}</p>}
    <button className="primary full" disabled={running} onClick={grade}>{running?(ocrDocuments?"Analysing validated text…":"Extracting text with Mistral…"):ocrDocuments?"Validate OCR text & generate learning-gap report":"Extract OCR text with Mistral"}</button>
  </>
}

function StudentGapsDialog({assessment,fileId,open}:any){
  const result:GradeResult|undefined=assessment.gradeResults?.[fileId];
  const file=(assessment.files||[]).find((f:UploadFile)=>f.id===fileId);
  if(!result)return <><DialogHead eyebrow={assessment.title} title="Learning gaps report"/><p className="modal-copy">This answer sheet has not been graded yet. Grade it first to unlock its learning gaps report.</p><button className="primary full" onClick={()=>open(`grade-file:${fileId}`)}>Grade this answer sheet</button></>;
  const sorted=result.gaps.slice().sort((a,b)=>a.mastery-b.mastery);
  if(!sorted.length)return <><DialogHead eyebrow={`${result.studentName} · ${file?.name||"Answer sheet"}`} title="Learning gaps report"/><div className="empty-state"><b>No evidence-supported learning gaps found</b><p>The analysis found no wrong, partially correct, incomplete or unanswered responses in the teacher-validated OCR text. Review the score and OCR evidence before approval.</p></div><button className="secondary full" onClick={()=>open(`grade-file:${fileId}`)}>Review validated OCR</button></>;
  const priority=sorted[0];
  return <><DialogHead eyebrow={`${result.studentName} · ${file?.name||"Answer sheet"}`} title="Learning gaps report"/>
    <div className="xray-summary">
      <Metric label="Score" value={`${result.score}/${result.maxMarks}`} note="AI-graded · teacher reviewable"/>
      <Metric label="Priority gap" value={priority.mastery+"%"} note={priority.concept}/>
      <Metric label="Concepts assessed" value={result.gaps.length} note={result.questionPaperName?`Against ${result.questionPaperName}`:"No question paper linked"}/>
    </div>
    <div className="diagnostic-gap-list">{sorted.map((g,index)=><article key={g.concept} className={g.mastery<55?"critical":""}><header><span>{index+1}</span><div><p>{g.severity||(g.mastery<55?"priority":"developing")} learning gap</p><h3>{g.concept}</h3></div><b>{g.mastery}% mastery</b></header><dl><div><dt>Diagnostic finding</dt><dd>{g.finding||`The response shows incomplete understanding of ${g.concept}.`}</dd></div><div><dt>Likely misunderstanding</dt><dd>{g.misconception||"The exact misconception was not captured in this earlier analysis. Reanalyse once to create the detailed diagnostic."}</dd></div><div><dt>Evidence from the answer</dt><dd>{g.evidence||result.feedback||"Review the OCR answer and teacher feedback for supporting evidence."}</dd></div><div><dt>What the child needs to rework</dt><dd>{g.rework||`Revisit the core idea, then practise explaining and applying ${g.concept}.`}</dd></div></dl></article>)}</div>
    <p className="modal-copy">The study guide will cover all {sorted.length} identified topic{sorted.length===1?"":"s"}, ordered from the most urgent knowledge gap to the strongest area.</p>
    <div className="button-row">
      <button className="secondary" onClick={()=>downloadStudentLearningGapReport(assessment,result,file)}>Download PDF Learning Gap Report</button>
      <button className="secondary" onClick={()=>open(`grade-file:${fileId}`)}>Regrade this sheet</button>
      <button className="primary" onClick={()=>open(`study-guide:${fileId}`)}>Generate study guide</button>
    </div>
  </>
}

function WorksheetDialog({setState,worksheet,sourceAssessment,sourceResult,presetConcept,presetTitle,presetStudent,done}:any){const concept=worksheet?.concept||presetConcept||"the target concept";const topics:string[]=worksheet?.concepts||sourceResult?.gaps?.map((g:Gap)=>g.concept)||[concept];const [subject,setSubject]=useState(worksheet?.subject||sourceAssessment?.subject||"");const [grade,setGrade]=useState(worksheet?.grade||sourceAssessment?.grade||"");const [generated,setGenerated]=useState(Boolean(worksheet?.content));const [generating,setGenerating]=useState(false);const [generationProgress,setGenerationProgress]=useState(0);const [genError,setGenError]=useState("");const [content,setContent]=useState<WorksheetContent|null>(worksheet?.content||null);const [template,setTemplate]=useState(worksheet?.template||"Guided recovery");const [mcq,setMcq]=useState(worksheet?.mcq??Math.max(6,topics.length*2));const [subjective,setSubjective]=useState(worksheet?.subjective??Math.max(4,topics.length));const [difficulty,setDifficulty]=useState(worksheet?.difficulty||"Mixed");const [title,setTitle]=useState(worksheet?.title||presetTitle||`${topics.join(", ")} Practice`);const save=()=>{const resource:Worksheet={id:worksheet?.id||`r${Date.now()}`,title,type:"Targeted worksheet",status:"Approved",template,concept:topics[0],concepts:topics,subject,grade,assessmentId:worksheet?.assessmentId||sourceAssessment?.id,studentName:worksheet?.studentName||presetStudent,mcq,subjective,difficulty,answerSheets:worksheet?.answerSheets||0,gradedSheets:worksheet?.gradedSheets||0,content:content||worksheet?.content};setState((s:DemoState)=>({...s,resources:worksheet?s.resources.map(r=>r.id===worksheet.id?resource:r):[resource,...s.resources],events:[`Worksheet saved · ${resource.title}`,...s.events]}));done()};
  const generate=async()=>{
    setGenError("");setGenerating(true);setGenerationProgress(5);
    const started=Date.now();const progressTimer=window.setInterval(()=>setGenerationProgress(Math.min(92,8+Math.round((Date.now()-started)/500))),1000);
    try{
      if(!subject.trim()||!grade.trim())throw new Error("Subject and Class are required.");
      if(mcq+subjective<topics.length)throw new Error(`Add at least ${topics.length} questions so every identified learning-gap topic is covered.`);
      const evidenceSummary=[sourceResult?.feedback,sourceResult?.ocrText,sourceAssessment?.files?.map((file:UploadFile)=>`${file.documentRole||inferDocumentRole(file.name)}: ${file.name}`).join("\n")].filter(Boolean).join("\n\n");
      const res=await authFetch("/api/generate-worksheet",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({concept:topics[0],concepts:topics,subject,grade,difficulty,template,mcqCount:mcq,subjectiveCount:subjective,evidenceSummary})});
      const payload=await res.json();
      logApiTiming(setState,payload?.timing);
      if(!res.ok)throw new Error(payload?.error||"Worksheet generation failed");
      delete payload.timing;
      const nextContent=payload as WorksheetContent;
      const covered=new Set([...nextContent.mcqQuestions,...nextContent.subjectiveQuestions].map(question=>question.concept?.trim().toLowerCase()).filter(Boolean));
      const missing=topics.filter(topic=>!covered.has(topic.trim().toLowerCase()));
      if(missing.length)throw new Error(`Worksheet generation missed these learning gaps: ${missing.join(", ")}. Regenerate to cover every topic.`);
      setGenerationProgress(100);setContent(nextContent);setGenerated(true);
      const resource:Worksheet={id:worksheet?.id||`worksheet-${sourceAssessment?.id||Date.now()}-${sourceResult?.fileId||"custom"}`,title,type:"Targeted worksheet",status:"Saved",template,concept:topics[0],concepts:topics,subject,grade,assessmentId:worksheet?.assessmentId||sourceAssessment?.id,studentName:worksheet?.studentName||presetStudent,mcq,subjective,difficulty,answerSheets:worksheet?.answerSheets||0,gradedSheets:worksheet?.gradedSheets||0,content:nextContent};
      setState((s:DemoState)=>({...s,resources:[resource,...s.resources.filter(r=>r.id!==resource.id)],events:[`Worksheet saved · ${resource.title}`,...s.events]}));
    }catch(err){
      setGenError(err instanceof Error?err.message:"Worksheet generation failed");
    }finally{
      clearInterval(progressTimer);setGenerating(false);
    }
  };
  return <><DialogHead eyebrow={presetStudent?`${presetStudent} · Learning-gap resource studio`:"Learning-gap resource studio"} title={worksheet?"Edit worksheet":"Create targeted worksheet"}/>
    <p className="modal-copy">Balanced practice covers every identified topic: <b>{topics.join(" · ")}</b>.</p>
    <div className="template-picker">{["Guided recovery","Quick check","Exam practice","Challenge & extend"].map(x=><button key={x} className={template===x?"active":""} onClick={()=>setTemplate(x)}><b>{x}</b><small>{x==="Guided recovery"?"Scaffolds + worked example":x==="Quick check"?"Short follow-up":x==="Exam practice"?"Mixed assessment style":"Deeper transfer tasks"}</small></button>)}</div>
    <Field label="Worksheet title"><input value={title} onChange={e=>setTitle(e.target.value)} required/></Field>
    <div className="form-grid"><Field label="Subject"><input value={subject} onChange={e=>setSubject(e.target.value)} required/></Field><Field label="Class"><input value={grade} onChange={e=>setGrade(e.target.value)} required/></Field><Field label="Difficulty"><select value={difficulty} onChange={e=>setDifficulty(e.target.value)}><option>Mixed</option><option>Foundation</option><option>Challenge</option></select></Field><Field label="Language"><select><option>English</option><option>Hindi</option></select></Field><Field label="Multiple-choice questions"><input type="number" min="0" max="30" value={mcq} onChange={e=>setMcq(Number(e.target.value))}/></Field><Field label="Subjective questions"><input type="number" min="0" max="20" value={subjective} onChange={e=>setSubjective(Number(e.target.value))}/></Field></div>
    {mcq+subjective<1&&<p className="form-error">Add at least one multiple-choice or subjective question.</p>}
    <label className="check"><input type="checkbox" defaultChecked/> Include worked example</label><label className="check"><input type="checkbox" defaultChecked/> Include answer key and marking guide</label>
    {generating&&<><Progress value={generationProgress}/><p className="modal-copy">Worksheet generation continues on the server · {generationProgress}% · safe to switch tabs</p></>}
    {genError&&<p className="form-error" role="alert">{genError}</p>}
    {generated&&content&&<div className="resource-draft branded-document"><BrandDocumentHeader label="Targeted practice worksheet" title={title} meta={`${subject} · ${grade} · ${topics.length} learning-gap topics`}/><p>{content.mcqQuestions.length} multiple-choice · {content.subjectiveQuestions.length} written response · answer key included</p><ol>{content.mcqQuestions.map((q,i)=><li key={i}><span className="question-number">{i+1}</span>{q.concept&&<span className="status">{q.concept}</span>} {q.question}<small>{q.options.map((o,j)=>`${String.fromCharCode(65+j)}) ${o}`).join("   ")}</small></li>)}{content.subjectiveQuestions.map((q,i)=><li key={`s${i}`}><span className="question-number">{content.mcqQuestions.length+i+1}</span>{q.concept&&<span className="status">{q.concept}</span>} {q.question}</li>)}</ol></div>}
    <button className="secondary full" disabled={mcq+subjective<1||!title.trim()||!subject.trim()||!grade.trim()||generating} onClick={generate}>{generating?"Generating balanced worksheet…":generated?"Regenerate and save worksheet":"Generate and save worksheet"}</button>
    {generated&&content&&<div className="button-row"><button className="secondary" onClick={()=>downloadWorksheet({title,template,concept:topics[0],concepts:topics,subject,grade,difficulty},content)}>Download PDF worksheet</button><button className="secondary" onClick={()=>downloadAnswerKey({title,subject,grade,concepts:topics},content)}>Download PDF answer key</button><button className="primary" onClick={save}>Approve resource</button></div>}</>}

function WorksheetGradingDialog({worksheet,setState,done}:any){
  const input=useRef<HTMLInputElement>(null);
  const [files,setFiles]=useState<File[]>([]);
  const [progress,setProgress]=useState(0);
  const [graded,setGraded]=useState(false);
  const [grading,setGrading]=useState(false);
  const [gradeError,setGradeError]=useState("");
  const [results,setResults]=useState<{studentName:string;score:number;maxMarks:number;mastery:number}[]>([]);
  const add=(list:FileList)=>setFiles(x=>[...x,...Array.from(list).filter(supportsDocumentUpload)]);
  const guessNameFromFile=(name:string)=>{const base=name.replace(/\.[^.]+$/,"").replace(/[_-]+/g," ").replace(/\b(answer|sheet|paper|qp|question|scan|img|copy|final|v\d+)\b/gi,"").replace(/\s+/g," ").trim();return base.length>2?base.split(" ").filter(Boolean).map(w=>w[0].toUpperCase()+w.slice(1)).join(" "):"Student"};
  const grade=async()=>{
    if(!files.length)return;
    setGradeError("");setGrading(true);let p=0;
    const timer=window.setInterval(()=>{p=Math.min(90,p+8);setProgress(p)},200);
    try{
      const graded_results=await Promise.all(files.map(async file=>{
        const fileBase64=await blobToBase64(file);
        const res=await authFetch("/api/grade",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
          subject:worksheet?.concept||"General",
          studentName:guessNameFromFile(file.name),
          fileName:file.name,
          maxMarks:10,
          answerKey:"",
          rubric:"",
          concepts:worksheet?.concept?[worksheet.concept]:[],
          fileBase64,
          mimeType:file.type
        })});
        const payload=await res.json();
        logApiTiming(setState,payload?.timing);
        if(!res.ok)throw new Error(payload?.error||`Grading failed for ${file.name}`);
        const gaps=payload.gaps||[];
        const mastery=gaps.length?Math.round(gaps.reduce((s:number,g:any)=>s+g.mastery,0)/gaps.length):Math.round((payload.score/Math.max(1,payload.maxMarks))*100);
        return {studentName:guessNameFromFile(file.name),score:payload.score,maxMarks:payload.maxMarks,mastery};
      }));
      clearInterval(timer);setProgress(100);setResults(graded_results);setGraded(true);
      setState((s:DemoState)=>({...s,resources:s.resources.map(r=>r.id===worksheet.id?{...r,answerSheets:(r.answerSheets||0)+files.length,gradedSheets:(r.gradedSheets||0)+files.length}:r),events:[`${files.length} worksheet answer sheets graded with EduAI · ${worksheet.title}`,...s.events]}));
    }catch(err){
      clearInterval(timer);
      setGradeError(err instanceof Error?err.message:"Grading failed");
    }finally{
      setGrading(false);
    }
  };
  return <><DialogHead eyebrow={worksheet?.title||"Worksheet"} title="Grade answer worksheets"/><div className="dropzone" role="button" tabIndex={0} onClick={()=>input.current?.click()} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();add(e.dataTransfer.files)}}><span>↑</span><b>Drop completed answer sheets or choose files</b><small>PDF, Word, Markdown, text or image · multiple students supported</small><button type="button" className="secondary">Browse / Choose File</button><input ref={input} className="file-input" type="file" multiple accept={DOCUMENT_ACCEPT} onChange={e=>e.target.files&&add(e.target.files)}/></div><div className="upload-list">{files.map((f,i)=><div key={`${f.name}${i}`}><span className="file-icon">{f.name.split(".").pop()?.toUpperCase()}</span><div><b>{f.name}</b><small>Ready for extraction and grading</small></div><button onClick={()=>setFiles(x=>x.filter((_,j)=>j!==i))}>×</button></div>)}</div>{progress>0&&<Progress value={progress}/>}{gradeError&&<p className="form-error" role="alert">{gradeError}</p>}{!graded?<button className="primary full" disabled={!files.length||grading} onClick={grade}>{grading?`Grading with EduAI… ${progress}%`:"Grade uploaded worksheets"}</button>:<><div className="grading-results"><b>Grading complete · teacher check required</b>{results.map((r,i)=><span key={i}>{r.studentName} · {r.score}/{r.maxMarks} · {r.mastery}% · {r.mastery>=80?"mastered":r.mastery>=60?"developing":"further practice"}</span>)}</div><div className="button-row"><button className="secondary" onClick={()=>downloadText(`${worksheet.title}-Graded-Results.csv`,`Student,Score,Mastery\n${results.map(r=>`${r.studentName},${r.score}/${r.maxMarks},${r.mastery}%`).join("\n")}`)}>Download graded results</button><button className="secondary" onClick={()=>downloadAnswerKey(worksheet)}>Check with answer key</button><button className="primary" onClick={done}>Teacher approves grades</button></div></>}</>}
function FollowupDialog({setState,intervention,done}:any){
  if(!intervention)return <><DialogHead eyebrow="Comparable evidence" title="Record follow-up"/><p className="modal-copy">This intervention could not be found. Close this dialog and try again from Interventions.</p></>;
  const submit=(e:FormEvent<HTMLFormElement>)=>{
    e.preventDefault();
    const f=new FormData(e.currentTarget);
    const evidence={studentsCompleted:Number(f.get("studentsCompleted"))||0,avgMastery:Number(f.get("avgMastery"))||0,outcome:String(f.get("outcome")),note:String(f.get("note"))};
    setState((s:DemoState)=>({
      ...s,
      interventions:s.interventions.map((i:Intervention)=>i.id===intervention.id?{...i,followupRecorded:true,followupEvidence:evidence}:i),
      events:[`Follow-up recorded · ${intervention.concept} · ${evidence.outcome}`,...s.events]
    }));
    done();
  };
  return <form onSubmit={submit}><DialogHead eyebrow={`Comparable evidence · ${intervention.concept}`} title="Record follow-up"/><Field label="Evidence type"><select><option>Exit ticket</option><option>Parallel quiz</option><option>Homework</option><option>Oral response</option><option>Observation rubric</option></select></Field><Field label="Comparability"><select><option>Strongly comparable</option><option>Moderately comparable</option><option>Informal evidence</option></select></Field><div className="form-grid"><Field label="Students completed"><input name="studentsCompleted" type="number" min="0" defaultValue="6"/></Field><Field label="Average mastery"><input name="avgMastery" type="number" min="0" max="100" defaultValue="68"/></Field></div><Field label="Outcome"><select name="outcome"><option>Meaningful improvement</option><option>Mastered after intervention</option><option>Some improvement</option><option>No clear improvement</option><option>Further support recommended</option></select></Field><Field label="Teacher observation"><textarea name="note" required defaultValue="Most students now identify the common denominator independently."/></Field><button className="primary full">Save follow-up evidence</button></form>}
function QualityDialog({assessment,state,done}:any){
  const evidenceSufficiency=assessment.totalReviews?Math.round((assessment.reviewed/assessment.totalReviews)*100):0;
  const results:GradeResult[]=Object.values(assessment.gradeResults||{});
  const conceptsGraded=new Set(results.flatMap(r=>r.gaps.map(g=>g.concept)));
  const conceptCount=conceptsGraded.size;
  const relevantWorksheets:Worksheet[]=(state?.resources||[]).filter((r:Worksheet)=>r.content&&(conceptsGraded.has(r.concept||"")||r.concept===undefined));
  const allQuestions=relevantWorksheets.flatMap(r=>[...(r.content?.mcqQuestions||[]),...(r.content?.subjectiveQuestions||[])]);
  const levelCounts={recall:0,application:0,analysis:0};
  allQuestions.forEach(q=>{if(q.cognitiveLevel in levelCounts)levelCounts[q.cognitiveLevel as CognitiveLevel]++});
  const totalTagged=allQuestions.length;
  let cognitiveBalancePct:number|null=null;
  if(totalTagged>0){
    const maxShare=Math.max(levelCounts.recall,levelCounts.application,levelCounts.analysis)/totalTagged;
    const evenShare=1/3;
    cognitiveBalancePct=Math.round(Math.max(0,Math.min(100,100-((maxShare-evenShare)/(1-evenShare))*100)));
  }
  return <><DialogHead eyebrow="Assessment Quality Check" title={evidenceSufficiency>=70?"Suitable with limitations":"Needs more evidence"}/><div className="quality-bars"><Bar label="Evidence sufficiency" pct={evidenceSufficiency}/><Bar label="Concepts with graded evidence" pct={Math.min(100,conceptCount*20)}/>{totalTagged>0&&<Bar label="Cognitive balance (recall/application/analysis spread)" pct={cognitiveBalancePct||0}/>}</div>{totalTagged>0&&<div className="insight">Cognitive balance measured from {totalTagged} real question{totalTagged===1?"":"s"} across {relevantWorksheets.length} generated worksheet{relevantWorksheets.length===1?"":"s"} for this concept area: {levelCounts.recall} recall · {levelCounts.application} application · {levelCounts.analysis} analysis. A perfectly even split scores 100; a set that's all one level scores lower.</div>}<div className="insight">{results.length?`${conceptCount} concept${conceptCount===1?"":"s"} have graded evidence so far.${totalTagged?"":" No generated worksheets with tagged questions exist yet for this concept area — create one in Worksheet studio to see cognitive-balance scoring."}`:"No graded evidence yet for this assessment. Grade at least one answer sheet to see real quality signals."}</div><button className="primary full" onClick={done}>Acknowledge recommendations</button></>}
function EvidenceDialog({state,id,done}:any){
  const [encStudent,encConcept]=(id||"").split(":");
  const studentName=decodeURIComponent(encStudent||"");
  const concept=decodeURIComponent(encConcept||"");
  const results=allGradeResults(state).filter(r=>r.studentName===studentName);
  const withGap=results.find(r=>r.gaps.some(g=>g.concept===concept));
  const gap=withGap?.gaps.find(g=>g.concept===concept);
  return <><DialogHead eyebrow={`Student evidence · ${studentName||"Unknown student"}`} title={concept||"Concept evidence"}/>
  {!withGap&&<p className="modal-copy">No graded evidence found for {studentName||"this student"} on "{concept}". Grade their answer sheet to populate this view.</p>}
  {withGap&&<><div className="evidence"><b>{concept} · {gap?.mastery}% mastery</b><p>{withGap.feedback||"No detailed feedback was returned for this answer sheet."}</p></div><div className="evidence"><b>Overall score</b><p>{withGap.score}/{withGap.maxMarks} marks{withGap.questionPaperName?` · graded against ${withGap.questionPaperName}`:""}</p></div></>}
  <Field label="Teacher classification"><select><option>Priority learning gap</option><option>Developing understanding</option><option>Performance issue</option><option>Insufficient evidence</option></select></Field><button className="primary full" onClick={done}>Save evidence decision</button></>}
function ReportDialog({done}:any){return <form onSubmit={e=>{e.preventDefault();done()}}><DialogHead eyebrow="Interactive reports" title="Generate report"/><Field label="Report type"><select><option>Student performance</option><option>Class heatmap</option><option>Concept mastery</option><option>Learning gaps</option><option>Teacher summary</option><option>School dashboard</option></select></Field><div className="form-grid"><Field label="Period"><select><option>Current month</option><option>Current term</option><option>Custom period</option></select></Field><Field label="Scope"><select><option>Class 6 · Mathematics</option><option>All classes</option><option>School-wide</option></select></Field></div><label className="check"><input type="checkbox" defaultChecked/> Include methodology and limitations</label><label className="check"><input type="checkbox" defaultChecked/> Aggregate student data</label><button className="primary full">Generate report</button></form>}
function ShareDialog({done}:any){
  const [created,setCreated]=useState(false);
  const [link,setLink]=useState("");
  const generateLink=()=>{
    const chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    const token=Array.from({length:8},()=>chars[Math.floor(Math.random()*chars.length)]).join("");
    const formatted=`${token.slice(0,4)}-${token.slice(4)}`;
    setLink(`eduai.demo/report/${formatted}`);
    setCreated(true);
  };
  return <><DialogHead eyebrow="Secure sharing" title="Leadership link"/><Field label="Expires"><select><option>7 days</option><option>30 days</option></select></Field><label className="check"><input type="checkbox" defaultChecked/> Require one-time code</label><label className="check"><input type="checkbox"/> Allow download</label>{created&&<div className="secure-link"><code>{link}</code><button onClick={()=>navigator.clipboard?.writeText(link)}>Copy</button></div>}<button className="primary full" onClick={()=>created?done():generateLink()}>{created?"Done":"Create secure link"}</button></>}
function InviteDialog({state,setState,done}:any){const [error,setError]=useState("");const submit=(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();const f=new FormData(e.currentTarget);const email=String(f.get("email")).toLowerCase();if(state.users.some((u:any)=>u.email.toLowerCase()===email)){setError("A user with this email already exists.");return}const u:User={id:`u${Date.now()}`,name:String(f.get("name")),email,role:String(f.get("role")),school:String(f.get("school")),phone:String(f.get("phone")||""),status:"Invited"};setState((s:DemoState)=>({...s,users:[u,...s.users],events:[`Invitation created · ${u.email}`,...s.events]}));done()};return <form onSubmit={submit}><DialogHead eyebrow="School administration" title="Invite user"/><Field label="Name"><input name="name" required minLength={2} placeholder="Teacher's full name"/></Field><Field label="Email address"><input name="email" type="email" required placeholder="teacher@school.edu"/></Field><div className="form-grid"><Field label="Role"><select name="role"><option>Teacher</option><option>Subject coordinator</option><option>Academic head</option><option>Principal</option><option>School administrator</option><option>Data operator</option></select></Field><Field label="School"><select name="school">{state.schools.map((s:string)=><option key={s} value={s.split(" · ")[0]}>{s.split(" · ")[0]}</option>)}</select></Field></div><Field label="Phone number (optional)"><input name="phone" type="tel" placeholder="+91 98765 43210"/></Field>{error&&<p className="form-error">{error}</p>}<button className="primary full">Send invitation</button></form>}
function UserEdit({user,setState,done}:any){const submit=(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();const f=new FormData(e.currentTarget);setState((s:DemoState)=>({...s,users:s.users.map(u=>u.id===user.id?{...u,name:String(f.get("name")),email:String(f.get("email")),role:String(f.get("role")),phone:String(f.get("phone"))}:u)}));done()};return <form onSubmit={submit}><DialogHead eyebrow="Manage user" title="Edit details"/><Field label="Name"><input name="name" required defaultValue={user.name}/></Field><Field label="Email"><input name="email" type="email" required defaultValue={user.email}/></Field><Field label="Role"><select name="role" defaultValue={user.role}><option>Teacher</option><option>Principal</option><option>School administrator</option><option>Data operator</option></select></Field><Field label="Phone"><input name="phone" defaultValue={user.phone}/></Field><button className="primary full">Save changes</button></form>}
function ClassDialog({state,setState,done}:any){const submit=(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();const f=new FormData(e.currentTarget);const className=String(f.get("className")||"").trim();const section=String(f.get("section")||"").trim().toUpperCase();const subject=String(f.get("subject")||"").trim();const x=`Class ${className}${section} · ${subject} · ${f.get("students")} students`;const prefix=`Class ${className}${section} · ${subject} ·`;setState((s:DemoState)=>({...s,classes:[x,...s.classes.filter(item=>!item.replace("Â·","·").startsWith(prefix))],events:[`Class subject created · Class ${className}${section} · ${subject}`,...s.events]}));done()};return <form onSubmit={submit}><DialogHead eyebrow="Class-first analysis" title="Create class & subject"/><p className="modal-copy">Create the class and section first, then attach its subject. Assessments and heatmaps use this exact structure.</p><div className="form-grid"><Field label="Class"><input name="className" required defaultValue="6"/></Field><Field label="Section"><input name="section" required defaultValue="C"/></Field><Field label="Subject"><input name="subject" required defaultValue="Mathematics"/></Field><Field label="Student strength"><input name="students" type="number" min="1" required defaultValue="30"/></Field></div><Field label="Assigned teacher"><select>{state.users.filter((u:any)=>u.role==="Teacher").map((u:any)=><option key={u.id}>{u.name}</option>)}</select></Field><button className="primary full">Save class & subject</button></form>}
function SchoolDialog({state,setState,done}:any){const submit=(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();const f=new FormData(e.currentTarget);const x=`${f.get("name")} · ${f.get("city")} · ${f.get("board")}`;setState((s:DemoState)=>({...s,schools:[x,...s.schools.filter(v=>!v.startsWith(String(f.get("name"))))]}));done()};return <form onSubmit={submit}><DialogHead eyebrow="Tenant profile" title="Manage school"/><Field label="School name"><input name="name" required defaultValue="Sunrise Academy"/></Field><div className="form-grid"><Field label="City"><input name="city" required defaultValue="Mumbai"/></Field><Field label="Board / curriculum"><select name="board"><option>CBSE</option><option>ICSE</option><option>State Board</option><option>IB</option></select></Field></div><Field label="Verified domain"><input type="text" defaultValue="sunrise.edu"/></Field><button className="primary full">Save school</button></form>}
function SimpleSettings({title,fields,done}:any){return <form onSubmit={e=>{e.preventDefault();done()}}><DialogHead eyebrow="Settings" title={title}/>{fields.map((x:string,i:number)=><Field key={x} label={x}>{i===1?<select><option>Enabled</option><option>Disabled</option><option>Approval required</option></select>:<input required defaultValue={i===0?"Current configuration":"School default"}/>}</Field>)}<button className="primary full">Save settings</button></form>}
function Activity({events,resetDemo,close}:any){return <><DialogHead eyebrow="Audit trail" title="Recent activity"/><div className="activity-list">{events.map((x:string,i:number)=><div key={i}><i>✓</i><span>{x}</span></div>)}</div><div className="button-row"><button className="secondary" onClick={()=>{resetDemo();close()}}>Restore sample data</button><button className="primary" onClick={close}>Done</button></div></>}
function NotificationDialog({state,done}:any){
  const recent:string[]=(state.events||[]).slice(0,5);
  return <><DialogHead eyebrow="Notifications" title="Your updates"/>
  {!recent.length&&<p className="modal-copy">No recent activity yet.</p>}
  {recent.map((x,i)=><div className="notification" key={i}><b>{x}</b></div>)}
  <button className="primary full" onClick={done}>Mark all as read</button></>}
function GroupDialog({state,id,done}:any){
  const [assessmentId,encConcept]=(id||"").split(":");
  const concept=decodeURIComponent(encConcept||"");
  const assessment=state.assessments.find((a:Assessment)=>a.id===assessmentId);
  const results:GradeResult[]=assessment?Object.values(assessment.gradeResults||{}):[];
  const affected=results.filter(r=>r.gaps.some(g=>g.concept===concept&&g.mastery<70)).map(r=>r.studentName);
  return <><DialogHead eyebrow="Temporary group" title={`Strengthen · ${affected.length} student${affected.length===1?"":"s"}`}/>
  {!affected.length&&<p className="modal-copy">No students currently below 70% mastery on "{concept}" from graded evidence.</p>}
  {affected.map(x=><label className="check" key={x}><input type="checkbox" defaultChecked/>{x}</label>)}
  <button className="primary full" onClick={done}>Save group membership</button></>}
function StudentDialog({setState,done}:any){const submit=(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();const f=new FormData(e.currentTarget);const student={id:`s${Date.now()}`,name:String(f.get("name")),roll:String(f.get("roll")),className:String(f.get("className")),status:"Active"};setState((s:DemoState)=>({...s,students:[student,...s.students],events:[`Student added · ${student.roll}`,...s.events]}));done()};return <form onSubmit={submit}><DialogHead eyebrow="School roster" title="Add student"/><Field label="Student name"><input name="name" required minLength={2}/></Field><div className="form-grid"><Field label="School student ID / roll"><input name="roll" required/></Field><Field label="Class"><select name="className"><option>Class 6A</option><option>Class 6B</option><option>Class 7A</option></select></Field></div><button className="primary full">Save student</button></form>}
function parseRosterCsv(text:string):{name:string;roll:string;className:string}[]{
  const lines=text.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);
  if(!lines.length)return[];
  const header=lines[0].split(",").map(h=>h.trim().toLowerCase());
  const nameIdx=header.findIndex(h=>h.includes("name"));
  const rollIdx=header.findIndex(h=>h.includes("roll")||h.includes("id"));
  const classIdx=header.findIndex(h=>h.includes("class")||h.includes("grade")||h.includes("section"));
  return lines.slice(1).map(line=>{
    const cols=line.split(",").map(c=>c.trim());
    return {
      name:nameIdx>=0?cols[nameIdx]||"":cols[0]||"",
      roll:rollIdx>=0?cols[rollIdx]||"":cols[1]||"",
      className:classIdx>=0?cols[classIdx]||"":cols[2]||"Class 6A"
    };
  }).filter(s=>s.name);
}
function rowsFromAOA(aoa:unknown[][]):{name:string;roll:string;className:string}[]{
  if(!aoa.length)return[];
  const header=(aoa[0]||[]).map(h=>String(h??"").trim().toLowerCase());
  const nameIdx=header.findIndex(h=>h.includes("name"));
  const rollIdx=header.findIndex(h=>h.includes("roll")||h.includes("id"));
  const classIdx=header.findIndex(h=>h.includes("class")||h.includes("grade")||h.includes("section"));
  return aoa.slice(1).map(row=>{
    const cols=row.map(c=>String(c??"").trim());
    return {
      name:nameIdx>=0?cols[nameIdx]||"":cols[0]||"",
      roll:rollIdx>=0?cols[rollIdx]||"":cols[1]||"",
      className:classIdx>=0?cols[classIdx]||"":cols[2]||"Class 6A"
    };
  }).filter(s=>s.name);
}
function RosterImport({setState,done}:any){
  const input=useRef<HTMLInputElement>(null);
  const [file,setFile]=useState<File|null>(null);
  const [error,setError]=useState("");
  const [busy,setBusy]=useState(false);
  const run=async()=>{
    if(!file){setError("Choose a CSV or XLSX roster.");return}
    setError("");setBusy(true);
    try{
      const lower=file.name.toLowerCase();
      let rows:{name:string;roll:string;className:string}[];
      if(lower.endsWith(".xlsx")||lower.endsWith(".xls")){
        const XLSX=await import("xlsx");
        const buf=await file.arrayBuffer();
        const wb=XLSX.read(buf,{type:"array"});
        const sheet=wb.Sheets[wb.SheetNames[0]];
        const aoa=XLSX.utils.sheet_to_json(sheet,{header:1,raw:false,defval:""}) as unknown[][];
        rows=rowsFromAOA(aoa);
      }else if(lower.endsWith(".csv")){
        const text=await file.text();
        rows=parseRosterCsv(text);
      }else{
        setError("Unsupported file type. Upload a .csv or .xlsx roster.");setBusy(false);return;
      }
      if(!rows.length){setError("No valid rows found. Make sure the file has a header row with Name, Roll and Class columns.");setBusy(false);return}
      setState((s:DemoState)=>({...s,students:[...s.students,...rows.map(r=>({id:`s${Date.now()}${Math.random().toString(36).slice(2,6)}`,name:r.name,roll:r.roll||"—",className:r.className,status:"Active"}))],events:[`Roster imported · ${file.name} · ${rows.length} student${rows.length===1?"":"s"}`,...s.events]}));
      done();
    }catch(err){
      setError(err instanceof Error?`Could not read the file: ${err.message}`:"Could not read the file.");
    }finally{
      setBusy(false);
    }
  };
  return <><DialogHead eyebrow="Roster import" title="Import students"/><div className="dropzone" role="button" tabIndex={0} onClick={()=>input.current?.click()} onKeyDown={e=>(e.key==="Enter"||e.key===" ")&&input.current?.click()}><span>⇧</span><b>{file?file.name:"Choose CSV or XLSX roster"}</b><small>Header row required with Name, Roll and Class columns. CSV and XLSX both parsed for real.</small><button type="button" className="secondary">Browse</button><input ref={input} className="file-input" type="file" accept=".csv,.xlsx,.xls" onChange={e=>{const f=e.target.files?.[0];if(f&&f.size>5*1024*1024)setError("Roster exceeds the 5 MB limit.");else{setFile(f||null);setError("")}}}/></div>{error&&<p className="form-error">{error}</p>}<button className="primary full" disabled={busy} onClick={run}>{busy?"Reading file…":"Validate & import roster"}</button></>}
function StudentEvidence({state,student,done}:any){
  const results:GradeResult[]=allGradeResults(state).filter(r=>r.studentName===student?.name);
  const m=studentMastery(state)[student?.name||""];
  const conceptAgg:Record<string,{sum:number;count:number}>={};
  results.forEach(r=>r.gaps.forEach(g=>{const b=conceptAgg[g.concept]||{sum:0,count:0};b.sum+=g.mastery;b.count+=1;conceptAgg[g.concept]=b}));
  const concepts=Object.entries(conceptAgg).map(([concept,b])=>({concept,mastery:Math.round(b.sum/b.count),evidence:b.count})).sort((a,b)=>a.mastery-b.mastery);
  const priority=concepts[0];
  return <><DialogHead eyebrow={`${student?.roll||"Student"} · evidence profile`} title={student?.name||"Student evidence"}/>
  {!results.length&&<p className="modal-copy">No graded evidence yet for {student?.name}. Grade one of their answer sheets to populate this profile.</p>}
  {results.length>0&&<><div className="xray-summary"><Metric label="Mastery" value={`${m?.mastery??0}%`} note={`${concepts.length} concept${concepts.length===1?"":"s"}`}/><Metric label="Evidence" value={String(m?.evidence??0)} note="Graded answer sheets"/><Metric label="Confidence" value={results.length>2?"High":results.length>1?"Medium":"Low"} note={`${results.length} assessment${results.length===1?"":"s"}`}/><Metric label="Last graded" value={m?.lastDate||"—"} note="Most recent evidence"/></div>
  <div className="evidence"><b>{priority?.concept||"No priority gap identified"} {priority?"· Priority gap":""}</b><p>{priority?`${priority.evidence} evidence point${priority.evidence===1?"":"s"} · average mastery ${priority.mastery}%`:"Grade more answer sheets to surface a priority concept."}</p></div></>}
  <Field label="Teacher observation"><select><option>No additional observation</option><option>Absence</option><option>Incomplete attempt</option><option>Time-management difficulty</option><option>Language difficulty</option><option>Careless mistake</option><option>Accommodation required</option></select></Field><button className="primary full" onClick={done}>Save observation</button></>
}
function AcademicYearDialog({setState,done}:any){const submit=(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();const f=new FormData(e.currentTarget);setState((s:DemoState)=>({...s,academicYears:[`${f.get("name")} · ${f.get("status")}`,...s.academicYears]}));done()};return <form onSubmit={submit}><DialogHead eyebrow="School calendar" title="Academic year"/><Field label="Name"><input name="name" required placeholder="2027–28"/></Field><div className="form-grid"><Field label="Start date"><input type="date" required/></Field><Field label="End date"><input type="date" required/></Field></div><Field label="Status"><select name="status"><option>Planned</option><option>Active</option><option>Archived</option></select></Field><button className="primary full">Save academic year</button></form>}
function ConsentDialog({done}:any){return <form onSubmit={e=>{e.preventDefault();done()}}><DialogHead eyebrow="Privacy & consent" title="Data-processing choices"/><label className="check"><input type="checkbox" required defaultChecked/> I accept the terms and privacy policy</label><label className="check"><input type="checkbox" required defaultChecked/> I am authorised to upload school and student data</label><label className="check"><input type="checkbox" required defaultChecked/> I understand AI-assisted processing and teacher approval</label><label className="check"><input type="checkbox"/> Allow anonymised product improvement</label><button className="primary full">Save consent choices</button></form>}
function SecurityDialog({done}:any){return <><DialogHead eyebrow="Sessions & security" title="Account protection"/><div className="list-item"><div><b>Windows · Chrome</b><small>Current session · Mumbai</small></div><span className="status success">Active</span></div><div className="list-item"><div><b>Android · Chrome</b><small>Last active 2 days ago</small></div><button onClick={()=>done()}>Revoke</button></div><label className="check"><input type="checkbox"/> Require MFA for administrator actions</label><button className="secondary full" onClick={done}>Log out all other devices</button></>}
function ConfirmDialog({eyebrow,title,text,action,onConfirm}:any){return <><DialogHead eyebrow={eyebrow} title={title}/><p className="modal-copy">{text}</p><button className="primary full" onClick={onConfirm}>{action}</button></>}

function PageHead({eyebrow,title,subtitle,children}:{eyebrow:string;title:string;subtitle:string;children?:ReactNode}){return <div className="page-heading"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{subtitle}</p></div><div className="button-row">{children}</div></div>}
function DialogHead({eyebrow,title}:{eyebrow:string;title:string}){return <><p className="eyebrow">{eyebrow}</p><h2>{title}</h2></>}
function CardHead({eyebrow,title,children}:{eyebrow:string;title:string;children?:ReactNode}){return <div className="card-head"><div><p className="eyebrow">{eyebrow}</p><h2>{title}</h2></div>{children}</div>}
function BrandDocumentHeader({label,title,meta}:{label:string;title:string;meta:string}){return <header className="brand-document-header"><img src="/brand/logo.png" alt="EduAI Hub"/><div><p>{label}</p><h2>{title}</h2><span>{meta}</span></div><i>Teacher-reviewed AI support</i></header>}
function Field({label,children}:{label:string;children:ReactNode}){return <label>{label}{children}</label>}
function Metric({label,value,note}:{label:string;value:any;note:string}){return <article className="metric"><span>{label}</span><b>{value}</b><small>{note}</small></article>}
function Bar({label,pct}:{label:string;pct:number}){return <div className="bar"><span>{label}<b>{pct}%</b></span><i><em style={{width:`${pct}%`}}/></i></div>}
function Progress({value}:{value:number}){return <div className="progress" aria-label={`${value}% complete`}><i style={{width:`${value}%`}}/><small>{value}%</small></div>}
function icon(x:string){return ({Home:"⌂",Work:"▣",Review:"✓","X-Ray":"✦",Interventions:"↗",Reports:"▥",Overview:"⌂",Users:"♙","Schools & Classes":"▦"} as any)[x]||"⚙"}
function stageProgress(stage:Stage){return ([10,25,38,50,62,72,80,88,95,100] as number[])[Object.keys(stageLabel).indexOf(stage)]}
function nextAction(stage:Stage){return ({draft:"Upload work",uploaded:"Set up rubric",setup:"Start grading",grading:"View processing",review:"Review answers",approved:"Generate X-Ray",xray:"Plan intervention",intervention:"Record follow-up",followup:"Publish grades",published:"View report"} as Record<Stage,string>)[stage]}
function assessmentHasGrades(a:Assessment){return Boolean(a.gradedFileIds?.length)||["review","approved","xray","intervention","followup","published"].includes(a.stage)}
function gapConceptsFor(subject:string){
  const s=(subject||"").toLowerCase();
  if(/math|arithmetic|algebra|geometry/.test(s))return["Equivalent fractions","Finding a common denominator","Adding after conversion","Word-problem translation"];
  if(/econom|micro|macro|commerce|business/.test(s))return["Price elasticity of demand","Market equilibrium shifts","Opportunity cost reasoning","Fiscal policy tools"];
  if(/physic/.test(s))return["Applying formulas correctly","Unit conversion","Free-body diagram accuracy","Interpreting graphs of motion"];
  if(/chemist/.test(s))return["Balancing chemical equations","Mole concept calculations","Naming compounds correctly","Reaction-type identification"];
  if(/biolog/.test(s))return["Diagram labelling accuracy","Process sequencing (e.g. cycles)","Cause-and-effect explanation","Applying the concept to a new example"];
  if(/science/.test(s))return["Diagram labelling accuracy","Cause-and-effect explanation","Unit conversion","Applying the concept to a new example"];
  if(/english|language|literature/.test(s))return["Grammar and sentence structure","Vocabulary in context","Comprehension inference","Structuring a written response"];
  if(/histor/.test(s))return["Chronological sequencing of events","Cause-and-effect reasoning","Source interpretation","Structuring an evidence-based answer"];
  if(/geograph/.test(s))return["Map reading and interpretation","Physical process explanation","Data/graph interpretation","Applying concepts to a real region"];
  if(/civic|political|social science/.test(s))return["Understanding institutions and their roles","Rights and responsibilities reasoning","Case-based application","Structuring an evidence-based answer"];
  if(/computer|programming|coding/.test(s))return["Logic and algorithmic thinking","Syntax accuracy","Debugging and tracing code","Applying concepts to a new problem"];
  if(/account/.test(s))return["Journal and ledger accuracy","Balancing entries correctly","Applying accounting principles","Financial statement interpretation"];
  return["Core concept understanding in "+ (subject||"this subject"),"Applying "+(subject||"the subject")+" methods to new problems","Explaining reasoning clearly","Accuracy under exam conditions"];
}
function guessStudentName(file:UploadFile,students:{name:string}[]){const base=file.name.replace(/\.[^.]+$/,"").replace(/[_\-]+/g," ").replace(/\b(answer|sheet|paper|qp|question|scan|img|copy|final|v\d+)\b/gi,"").replace(/\s+/g," ").trim();if(base.length>2)return base.split(" ").filter(Boolean).map(w=>w[0].toUpperCase()+w.slice(1)).join(" ");return students[Math.floor(Math.random()*students.length)]?.name||"Student";}
function worksheetContent(r:any,content?:{mcqQuestions:{question:string;options:string[];correctIndex:number}[];subjectiveQuestions:{question:string;modelAnswer:string}[]}){
  const mcqLines=(content?.mcqQuestions||[]).map((q,i)=>`${i+1}. ${q.question} ${q.options.map((o,j)=>`${String.fromCharCode(65+j)}) ${o}`).join(" ")}`).join("\n");
  const subjLines=(content?.subjectiveQuestions||[]).map((q,i)=>`${i+1}. ${q.question}`).join("\n");
  return `${r.title}\n\nTarget learning gap: ${r.concept||"Teacher-defined concept"}\nTemplate: ${r.template||"Custom"}\nDifficulty: ${r.difficulty||"Mixed"}\n\nMULTIPLE CHOICE (${content?.mcqQuestions.length||0})\n${mcqLines||"(none)"}\n\nSUBJECTIVE (${content?.subjectiveQuestions.length||0})\n${subjLines||"(none)"}\n\nTeacher: __________________  Student: __________________  Date: __________`;
}
function downloadText(name:string,content:string){
  const rows=content.trim().split(/\r?\n/).map(line=>line.split(","));
  const table=rows.length>1?`<table class="data-table"><thead><tr>${rows[0].map(cell=>`<th>${htmlEscape(cell)}</th>`).join("")}</tr></thead><tbody>${rows.slice(1).map(row=>`<tr>${row.map(cell=>`<td>${htmlEscape(cell)}</td>`).join("")}</tr>`).join("")}</tbody></table>`:`<p>${htmlEscape(content)}</p>`;
  void downloadDocument(name.replace(/\.[^.]+$/,""),name.replace(/\.[^.]+$/,"").replace(/[-_]+/g," "),"EduAI Hub · Teacher resource",`<h2>Results</h2>${table}`);
}
function htmlEscape(value:any){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]||c))}
function normalizeOcrText(value:string){
  return String(value||"").replace(/```(?:text|markdown)?/gi,"").replace(/[^\S\r\n]+/g," ").replace(/\s*([|¦•·])\s*/g," ").replace(/\n{3,}/g,"\n\n").split("\n").map(line=>line.trim()).join("\n").trim();
}
async function brandLogoDataUri(){
  try{const response=await fetch("/brand/logo.png");if(!response.ok)return "/brand/logo.png";return await blobToDataUri(await response.blob())}catch{return "/brand/logo.png"}
}
function blobToDataUri(blob:Blob):Promise<string>{return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result||""));reader.onerror=()=>reject(reader.error);reader.readAsDataURL(blob)})}
function documentFlowVisual(){return `<table class="visual-flow" role="presentation"><tr><td><b>1 · EVIDENCE</b><small>Teacher review required</small></td><td class="arrow">→</td><td><b>2 · INSIGHT</b><small>Draft learning diagnosis</small></td><td class="arrow">→</td><td><b>3 · ACTION</b><small>Approve before use</small></td></tr></table>`}
function masteryVisual(label:string,value:number){const safe=Math.max(0,Math.min(100,Number(value)||0));const colour=safe>=80?"#2d7a45":safe<=35?"#b63d34":"#d58a10";return `<table class="mastery-visual" role="presentation"><tr><td class="visual-label">${htmlEscape(label)}</td><td class="bar-track"><span style="display:block;width:${safe}%;height:12px;background:${colour}">&nbsp;</span></td><td class="visual-value">${safe}%</td></tr></table>`}
function textToDocumentHtml(value:string){
  const lines=String(value||"").replace(/\r/g,"").split("\n");
  let listOpen=false;
  const html=lines.map(raw=>{
    const line=raw.trim();
    if(!line){const close=listOpen?"</ol>":"";listOpen=false;return `${close}<div class="spacer"></div>`}
    const heading=line.match(/^(#{1,3})\s+(.+)$/);
    if(heading){const close=listOpen?"</ol>":"";listOpen=false;const level=Math.min(3,heading[1].length+1);return `${close}<h${level}>${htmlEscape(heading[2])}</h${level}>`}
    const numbered=line.match(/^(?:Q(?:uestion)?\s*)?(\d+)[.)]\s*(.+)$/i);
    if(numbered){const open=listOpen?"":"<ol>";listOpen=true;return `${open}<li><b>${htmlEscape(numbered[1])}.</b> ${htmlEscape(numbered[2])}</li>`}
    const close=listOpen?"</ol>":"";listOpen=false;
    return `${close}<p>${htmlEscape(line).replace(/\*\*(.+?)\*\*/g,"<b>$1</b>")}</p>`;
  }).join("");
  return html+(listOpen?"</ol>":"");
}
function brandedDocumentHtml(title:string,meta:string,body:string,logo:string){
  return `<article class="pdf-document"><header class="cover"><img class="header-logo" src="${logo}" alt="EduAI Hub"><div class="brand">EduAI Hub · Learning X-Ray</div><h1>${htmlEscape(title)}</h1><div class="meta">${htmlEscape(meta)}</div></header>${documentFlowVisual()}${body}<footer class="closing-footer"><img src="${logo}" alt="EduAI Hub">Prepared with EduAI Learning X-Ray · Teacher review recommended before classroom use</footer></article>`;
}
const PDF_DOCUMENT_STYLES=`*{box-sizing:border-box}.pdf-document{width:760px;background:#fff;color:#172644;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.52;padding:0 8px 24px}.cover{border-bottom:5px solid #f6a017;padding:0 0 18px;margin-bottom:18px}.header-logo{display:block;width:210px;height:auto;margin:0 0 13px}.brand{font-size:11px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:#e98200}.cover h1{font-size:30px;line-height:1.12;margin:8px 0;color:#172644}.meta{color:#667085;font-size:13px}h2{font-size:21px;color:#22365e;border-bottom:2px solid #d9dee8;padding-bottom:7px;margin:25px 0 11px}h3{font-size:16px;color:#283b65;margin:19px 0 7px}p{margin:7px 0 11px}.spacer{height:5px}.topic{page-break-inside:avoid;border:1px solid #cfd8e7;border-radius:9px;padding:16px;margin:16px 0;background:#fff}.label{display:inline-block;background:#eef3fb;color:#283b65;border-radius:12px;padding:4px 9px;font-size:10px;font-weight:700;margin-right:6px}ol{padding-left:25px}li{margin:0 0 12px}.options{margin:8px 0 0;color:#475467}.answer{background:#fff8ec;border-left:5px solid #f6a017;border-radius:4px;padding:11px 13px;margin:9px 0}.visual-flow{width:100%;border-collapse:separate;border-spacing:6px;margin:0 0 24px}.visual-flow td:not(.arrow){width:29%;background:#eef3fb;border:1px solid #cfd8e7;border-radius:7px;text-align:center;padding:10px;color:#283b65}.visual-flow small{display:block;color:#667085;margin-top:3px}.visual-flow .arrow{width:6%;text-align:center;color:#f08d00;font-size:19px}.mastery-visual{width:100%;border-collapse:collapse;margin:9px 0}.visual-label{width:34%;font-weight:700;padding-right:8px}.bar-track{width:55%;background:#e6eaf0}.visual-value{width:11%;text-align:right;font-weight:700}.data-table,table{width:100%;border-collapse:collapse}.data-table th,.data-table td,table th,table td{border:1px solid #d9dee8;padding:8px;text-align:left}.data-table th,table thead th{background:#283b65;color:#fff}.executive{page-break-inside:avoid}.closing-footer{margin-top:30px;padding-top:10px;border-top:1px solid #d9dee8;color:#667085;font-size:10px}.closing-footer img{width:68px;height:auto;vertical-align:middle;margin-right:10px}`;
async function createBrandedPdfBlob(title:string,meta:string,body:string){
  const logo=await brandLogoDataUri();
  const host=document.createElement("div");
  host.style.cssText="position:fixed;left:-100000px;top:0;width:780px;background:#fff;z-index:2147483647;pointer-events:none";
  host.innerHTML=`<style>${PDF_DOCUMENT_STYLES}</style>${brandedDocumentHtml(title,meta,body,logo)}`;
  document.body.appendChild(host);
  try{
    await document.fonts?.ready;
    const canvas=await html2canvas(host,{backgroundColor:"#ffffff",scale:1.5,useCORS:true,logging:false,windowWidth:780});
    const pdf=new jsPDF({orientation:"portrait",unit:"mm",format:"a4",compress:true});
    const contentWidthMm=182,contentHeightMm=266;
    const pageHeightPx=Math.max(1,Math.floor(canvas.width*(contentHeightMm/contentWidthMm)));
    const pages=Math.max(1,Math.ceil(canvas.height/pageHeightPx));
    for(let page=1;page<=pages;page++){
      if(page>1)pdf.addPage();
      pdf.setPage(page);
      const sourceY=(page-1)*pageHeightPx;
      const sourceHeight=Math.min(pageHeightPx,canvas.height-sourceY);
      const slice=document.createElement("canvas");slice.width=canvas.width;slice.height=sourceHeight;
      const context=slice.getContext("2d");if(!context)throw new Error("PDF renderer could not create a page canvas.");
      context.fillStyle="#ffffff";context.fillRect(0,0,slice.width,slice.height);context.drawImage(canvas,0,sourceY,canvas.width,sourceHeight,0,0,canvas.width,sourceHeight);
      pdf.addImage(slice.toDataURL("image/jpeg",0.92),"JPEG",14,12,contentWidthMm,contentWidthMm*(sourceHeight/canvas.width),undefined,"FAST");
      pdf.setDrawColor(217,222,232);pdf.line(14,282,196,282);
      try{pdf.addImage(logo,"PNG",14,285,20,5.8,undefined,"FAST")}catch{}
      pdf.setFont("helvetica","normal");pdf.setFontSize(8);pdf.setTextColor(102,112,133);
      pdf.text("EduAI Hub · Learning X-Ray",38,289);pdf.text(`Page ${page} of ${pages}`,196,289,{align:"right"});
    }
    return pdf.output("blob");
  }finally{host.remove()}
}
async function downloadDocument(name:string,title:string,meta:string,body:string){
  const blob=await createBrandedPdfBlob(title,meta,body);
  const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`${name.replace(/\.[^.]+$/,"").replace(/[^a-z0-9-]+/gi,"-")}.pdf`;a.click();window.setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function downloadWorksheet(r:any,content?:WorksheetContent){content=content||r.content;const questions=[...(content?.mcqQuestions||[]).map((q:any,i:number)=>`<li><span class="label">${htmlEscape(q.concept||"Topic")}</span><b>${i+1}. ${htmlEscape(q.question)}</b><div class="options">${q.options.map((o:string,j:number)=>`${String.fromCharCode(65+j)}. ${htmlEscape(o)}`).join("<br>")}</div></li>`),...(content?.subjectiveQuestions||[]).map((q:any,i:number)=>`<li><span class="label">${htmlEscape(q.concept||"Topic")}</span><b>${(content?.mcqQuestions.length||0)+i+1}. ${htmlEscape(q.question)}</b><p>Answer:</p><br><br></li>`)].join("");downloadDocument(r.title||"Worksheet",r.title||"Worksheet",`${r.subject||"Subject"} · ${r.grade||"Class not set"} · ${(r.concepts||[r.concept]).filter(Boolean).join(" · ")}`,`<h2>Student details</h2><p>Name: ____________________ &nbsp;&nbsp; Date: __________ &nbsp;&nbsp; Teacher: ____________________</p><h2>Instructions</h2><p>Answer every question. Show working or supporting evidence where required.</p><ol>${questions}</ol>`)}
function downloadAnswerKey(r:any,content?:{mcqQuestions:{question:string;options:string[];correctIndex:number}[];subjectiveQuestions:{question:string;modelAnswer:string}[]}){
  content=content||r.content;
  const mcqKey=(content?.mcqQuestions||[]).map((q:any,i)=>`<div class="answer"><span class="label">${htmlEscape(q.concept||"Topic")}</span><b>${i+1}. ${String.fromCharCode(65+q.correctIndex)}</b> — ${htmlEscape(q.options[q.correctIndex])}</div>`).join("");
  const subjKey=(content?.subjectiveQuestions||[]).map((q:any,i)=>`<div class="answer"><span class="label">${htmlEscape(q.concept||"Topic")}</span><b>${(content?.mcqQuestions.length||0)+i+1}. Model answer</b><p>${htmlEscape(q.modelAnswer)}</p></div>`).join("");
  downloadDocument(`${r.title||"Worksheet"}-Answer-Key`,`${r.title||"Worksheet"} · Answer Key`,`${r.subject||"Subject"} · ${r.grade||"Class not set"}`,`<h2>Multiple-choice answers</h2>${mcqKey||"<p>None</p>"}<h2>Written-response marking guide</h2>${subjKey||"<p>None</p>"}`);
}
function downloadStudyGuide(r:any,guide:any){const topics=(guide?.topics||[]).map((t:any,i:number)=>`<section class="topic"><span class="label">Topic ${i+1}</span><span class="label">${htmlEscape(t.mastery)}% starting mastery</span><h2>${htmlEscape(t.concept)}</h2><h3>Why this matters</h3><p>${htmlEscape(t.diagnosis)}</p><h3>Learning objective</h3><p>${htmlEscape(t.learningObjective)}</p><h3>Clear explanation</h3><p>${htmlEscape(t.explanation)}</p><h3>Worked example</h3><div class="answer">${htmlEscape(t.workedExample)}</div><h3>Guided practice</h3><ol>${(t.practiceSteps||[]).map((x:string)=>`<li>${htmlEscape(x)}</li>`).join("")}</ol><h3>Check for understanding</h3><ol>${(t.checkForUnderstanding||[]).map((x:string)=>`<li>${htmlEscape(x)}</li>`).join("")}</ol></section>`).join("");downloadDocument(r.title||"Study-Guide",r.title||"Study Guide",`${r.subject||"Subject"} · ${r.grade||"Class not set"} · ${r.studentName||"Student"}`,`<p>${htmlEscape(guide?.overview||"")}</p>${topics}`)}
function learningGapExecutiveSummary(gaps:{concept:string;mastery:number}[]){
  return `<section class="executive" style="background:#eef3fb;border-left:6px solid #283b65;padding:16px 20px;margin:18px 0 26px"><h2>Executive summary</h2><p>The following learning gaps were identified from the analysed evidence:</p>${gaps.slice().sort((a,b)=>a.mastery-b.mastery).map(g=>masteryVisual(g.concept,g.mastery)).join("")}</section>`;
}
function downloadStudentLearningGapReport(assessment:Assessment,result:GradeResult,file?:UploadFile){
  const details=result.gaps.slice().sort((a,b)=>a.mastery-b.mastery).map((g,index)=>`<section class="topic"><span class="label">Gap ${index+1}</span><span class="label">${g.mastery}% mastery</span><h2>${htmlEscape(g.concept)}</h2>${masteryVisual(g.concept,g.mastery)}<h3>Diagnostic finding</h3><p>${htmlEscape(g.finding||"Incomplete understanding identified.")}</p><h3>Likely misunderstanding</h3><p>${htmlEscape(g.misconception||"Review the validated evidence for the likely misconception.")}</p><h3>Evidence</h3><p>${htmlEscape(g.evidence||result.feedback||"Teacher-reviewed answer evidence.")}</p><h3>Required rework</h3><p>${htmlEscape(g.rework||`Revisit and practise ${g.concept}.`)}</p></section>`).join("");
  const percentage=Math.round((result.score/Math.max(1,result.maxMarks))*100);
  const performance=percentage>=80?"Strong performance":percentage>=60?"Developing performance":percentage>=40?"Needs targeted support":"Priority support required";
  const gapRows=result.gaps.slice().sort((a,b)=>a.mastery-b.mastery).map((g,index)=>{const status=g.mastery<55?"Priority":g.mastery<80?"Developing":"Secure";const colour=g.mastery<55?"#9f2d24":g.mastery<80?"#8a5a00":"#23672d";return `<tr><td style="padding:7px 8px;border-bottom:1px solid #e3e8f0">${index+1}. ${htmlEscape(g.concept)}</td><td style="padding:7px 8px;border-bottom:1px solid #e3e8f0"><b>${g.mastery}%</b></td><td style="padding:7px 8px;border-bottom:1px solid #e3e8f0;color:${colour};font-weight:700">${status}</td></tr>`}).join("");
  const detailRow=(label:string,value:string|number)=>`<tr><th style="width:43%;padding:7px 8px;border-bottom:1px solid #e3e8f0;background:#f7f9fc;text-align:left;color:#475467">${label}</th><td style="padding:7px 8px;border-bottom:1px solid #e3e8f0">${value}</td></tr>`;
  const panelStyle="background:#fff;border:1px solid #ccd6e5;border-radius:8px;overflow:hidden";
  const panelHeadingStyle="background:#283b65;color:#fff;font-size:11px;letter-spacing:.04em;text-transform:uppercase;margin:0;padding:9px 11px";
  const summary=`<section class="executive" style="background:#eef3fb;border-left:6px solid #283b65;border-radius:10px;padding:16px 18px;margin:18px 0 26px;page-break-inside:avoid"><h2 style="border:0;margin:0 0 14px;padding:0">Executive summary</h2><div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.2fr);gap:14px;align-items:start"><div style="${panelStyle}"><h3 style="${panelHeadingStyle}">Student & assessment details</h3><table style="width:100%;border-collapse:collapse;font-size:9.5pt;line-height:1.35"><tbody>${detailRow("Student Name",htmlEscape(result.studentName))}${detailRow("Class",`Class ${htmlEscape(assessment.grade)}${htmlEscape(assessment.section)}`)}${detailRow("Subject",htmlEscape(assessment.subject))}${detailRow("Assessment",htmlEscape(assessment.title))}${detailRow("Answer Sheet",htmlEscape(file?.name||"Uploaded evidence"))}${detailRow("Total Marks",result.maxMarks)}${detailRow("Marks Obtained",result.score)}${detailRow("Percentage",`${percentage}%`)}${detailRow("Overall Performance",`<b>${performance}</b>`)}</tbody></table></div><div style="${panelStyle}"><h3 style="${panelHeadingStyle}">Learning-gap summary</h3><table style="width:100%;border-collapse:collapse;font-size:9.5pt;line-height:1.35"><thead><tr><th style="padding:7px 8px;background:#f0f4fa;text-align:left">Gap</th><th style="padding:7px 8px;background:#f0f4fa;text-align:left">Mastery</th><th style="padding:7px 8px;background:#f0f4fa;text-align:left">Status</th></tr></thead><tbody>${gapRows}</tbody></table></div></div></section>`;
  downloadDocument(`${result.studentName}-Learning-Gap-Report`,"Learning Gap Report",`Class ${assessment.grade}${assessment.section} · ${assessment.subject} · ${assessment.title}`,`${summary}${details}`);
}
function downloadClassLearningGapReport(assessment:Assessment,results:GradeResult[]){
  const totals=new Map<string,{sum:number;count:number}>();
  results.forEach(result=>result.gaps.forEach(g=>{const item=totals.get(g.concept)||{sum:0,count:0};item.sum+=g.mastery;item.count++;totals.set(g.concept,item)}));
  const gaps=Array.from(totals,([concept,item])=>({concept,mastery:Math.round(item.sum/item.count)})).sort((a,b)=>a.mastery-b.mastery);
  const students=results.map(result=>`<tr><td>${htmlEscape(result.studentName)}</td><td>${result.score}/${result.maxMarks}</td><td>${htmlEscape(result.gaps.slice().sort((a,b)=>a.mastery-b.mastery)[0]?.concept||"No gap identified")}</td></tr>`).join("");
  downloadDocument(`${assessment.title}-Class-Learning-Gap-Report`,"Class Learning Gap Report",`Class ${assessment.grade}${assessment.section} · ${assessment.subject} · ${assessment.title} · ${results.length} student${results.length===1?"":"s"}`,`${learningGapExecutiveSummary(gaps)}<h2>Student analysis</h2><table><thead><tr><th>Student</th><th>Score</th><th>Priority learning gap</th></tr></thead><tbody>${students}</tbody></table>`);
}
function reportTitle(tab:string){return ({ "Student performance":"Class 6 performance trend","Class heatmap":"Class 6A concept heatmap","Concept mastery":"Mastery by concept","Learning gaps":"Priority learning gaps","Teacher summary":"Teacher-approved activity summary","School dashboard":"School improvement overview"} as any)[tab]}
function dialogTitle(x:string){return x.split("-").map(v=>v[0]?.toUpperCase()+v.slice(1)).join(" ")}

function inferDocumentRole(name:string):DocumentRole{
  if(/marking.?scheme|mark.?scheme/i.test(name))return "Marking scheme";
  if(/model.?answer|answer.?key|solution/i.test(name))return "Model answer";
  if(/question|paper|worksheet|assessment|\\bqp\\b/i.test(name))return "Question paper";
  if(/graded|marked|checked/i.test(name))return "Teacher-graded answer sheet";
  return "Ungraded answer sheet";
}
function isQuestionPaperFile(file:UploadFile,total:number){return file.documentRole==="Question paper"||(!file.documentRole&&total>1&&/question|paper|qp/i.test(file.name))}
function isAnswerSheetFile(file:UploadFile,total:number){return file.documentRole==="Ungraded answer sheet"||file.documentRole==="Teacher-graded answer sheet"||(!file.documentRole&&!isQuestionPaperFile(file,total)&&!(/answer.?key|model.?answer|marking.?scheme|solutions?/i.test(file.name)))}

function UploadedFiles({assessment,update,notify,open}:any){
  const files:UploadFile[]=assessment.files||[];
  const retrieve=async(file:UploadFile,download=false)=>{
    const blob=await readFileBlob(file.id);
    if(!blob){notify("The original file is not available in secure storage. Upload it again to restore preview and download.","warning");return}
    const url=URL.createObjectURL(blob);
    if(!download){window.open(url,"_blank","noopener,noreferrer");return}
    if(blob.type==="application/pdf"||/\.pdf$/i.test(file.name)){
      const a=document.createElement("a");a.href=url;a.download=file.name.replace(/\.[^.]+$/,"")+".pdf";a.click();window.setTimeout(()=>URL.revokeObjectURL(url),1000);return;
    }
    URL.revokeObjectURL(url);
    let body="";
    if(blob.type.startsWith("image/"))body=`<section class="topic"><img src="${await blobToDataUri(blob)}" alt="${htmlEscape(file.name)}" style="display:block;max-width:100%;height:auto;margin:0 auto"></section>`;
    else if(blob.type.startsWith("text/")||/\.(md|markdown|txt|rtf|html?|xml|json|ya?ml|csv|tsv)$/i.test(file.name))body=textToDocumentHtml(await blob.text());
    else{
      const response=await authFetch("/api/document-to-pdf-source",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:file.name,mimeType:blob.type||"application/octet-stream",base64:await blobToBase64(blob)})});
      const payload=await response.json();
      if(!response.ok)throw new Error(payload?.error||"This document could not be converted to PDF.");
      body=textToDocumentHtml(String(payload.text||""));
    }
    await downloadDocument(file.name.replace(/\.[^.]+$/,""),file.documentRole||inferDocumentRole(file.name),`${assessment.title} · Converted to a classroom-ready PDF`,body);
  };
  const remove=async(file:UploadFile)=>{await removeFileBlob(file.id);update(assessment.id,{files:files.filter(f=>f.id!==file.id)});notify(`${file.name} removed`)};
  const openGaps=(file:UploadFile,graded:boolean)=>{if(graded)open(`student-gaps:${file.id}`);else{notify("Grade this answer sheet first to unlock its learning gaps report","warning");open(`grade-file:${file.id}`)}};
  return <section className="card span-2 uploaded-files-card"><CardHead eyebrow={`${files.length} file${files.length===1?"":"s"} · ${assessment.title}`} title="Uploaded evidence"><button className="primary" onClick={()=>open("upload")}>＋ Add files</button></CardHead>{files.length===0?<div className="empty-state"><b>No evidence uploaded yet</b><p>Add question papers, model answers, and graded or ungraded answer sheets.</p><button className="secondary" onClick={()=>open("upload")}>Browse files</button></div>:<div className="uploaded-files-grid">{files.map(file=>{const answer=isAnswerSheetFile(file,files.length);const graded=Boolean(assessment.gradeResults?.[file.id]);return <article key={file.id}><span className="file-icon">{file.name.split(".").pop()?.toUpperCase()}</span><div><b>{file.name}</b><small>{file.documentRole||inferDocumentRole(file.name)} · {(file.size/1024/1024).toFixed(2)} MB · {file.status}{graded?" · Analysed":""}</small></div><div className="button-row">{answer&&<button className="primary" onClick={()=>open(`grade-file:${file.id}`)}>{graded?"Reanalyse":"Analyse answer sheet"}</button>}{answer&&<button className="secondary" onClick={()=>openGaps(file,graded)}>{graded?"Learning gaps report":"Learning gaps (analyse first)"}</button>}<button className="secondary" onClick={()=>retrieve(file)}>Preview</button><button className="secondary" onClick={()=>retrieve(file,true)}>Download</button><button className="link danger" onClick={()=>remove(file)}>Remove</button></div></article>})}</div>}<p className="storage-note">Every report and generated resource stays linked to these classified source documents.</p></section>
}

function openFileDb():Promise<IDBDatabase>{return new Promise((resolve,reject)=>{const request=indexedDB.open("eduai-learning-xray-files",1);request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains("files"))request.result.createObjectStore("files")};request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error)})}
async function saveLocalFileBlob(id:string,file:Blob){const db=await openFileDb();await new Promise<void>((resolve,reject)=>{const tx=db.transaction("files","readwrite");tx.objectStore("files").put(file,id);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)});db.close()}
async function readLocalFileBlob(id:string):Promise<Blob|null>{const db=await openFileDb();const value=await new Promise<any>((resolve,reject)=>{const request=db.transaction("files").objectStore("files").get(id);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error)});db.close();return value||null}
async function removeLocalFileBlob(id:string){const db=await openFileDb();await new Promise<void>((resolve,reject)=>{const tx=db.transaction("files","readwrite");tx.objectStore("files").delete(id);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)});db.close()}
async function saveFileBlob(id:string,file:Blob){await saveLocalFileBlob(id,file);const response=await authFetch(`/api/files/${encodeURIComponent(id)}`,{method:"PUT",headers:{"Content-Type":file.type||"application/octet-stream"},body:file});if(!response.ok)throw new Error("Cloud file upload failed")}
async function readFileBlob(id:string):Promise<Blob|null>{const cached=await readLocalFileBlob(id);if(cached)return cached;try{const response=await authFetch(`/api/files/${encodeURIComponent(id)}`);if(!response.ok)return null;const blob=await response.blob();await saveLocalFileBlob(id,blob);return blob}catch{return null}}
async function removeFileBlob(id:string){await removeLocalFileBlob(id);await authFetch(`/api/files/${encodeURIComponent(id)}`,{method:"DELETE"})}
function blobToBase64(blob:Blob):Promise<string>{return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onloadend=()=>{const result=reader.result as string;resolve(result.split(",")[1]||"")};reader.onerror=()=>reject(reader.error);reader.readAsDataURL(blob)})}

function UploadDialogV2({assessment,update,done}:any){
  const input=useRef<HTMLInputElement>(null),pauseRef=useRef(false),pendingUploads=useRef(new Map<string,Promise<void>>());
  const [files,setFiles]=useState<UploadFile[]>(assessment.files||[]);
  const [error,setError]=useState(""),[uploading,setUploading]=useState(false),[paused,setPaused]=useState(false);
  const roles:DocumentRole[]=["Question paper","Marking scheme","Model answer","Ungraded answer sheet","Teacher-graded answer sheet","Supporting reference"];
  const add=(list:FileList|File[])=>{setError("");const next:UploadFile[]=[];Array.from(list).forEach(file=>{if(!supportsDocumentUpload(file)){setError(`${file.name}: unsupported format. Use PDF, Word, Markdown, text, spreadsheet or an image.`);return}if(file.size>10*1024*1024){setError(`${file.name}: exceeds the 10 MB limit.`);return}const id=`f${crypto.randomUUID()}`;next.push({id,name:file.name,type:file.type||"application/octet-stream",size:file.size,progress:0,status:"Saving securely",documentRole:"Ungraded answer sheet",preview:file.type.startsWith("image/")&&!file.type.includes("heic")?URL.createObjectURL(file):undefined});const pending=saveFileBlob(id,file).then(()=>setFiles(items=>items.map(item=>item.id===id?{...item,status:"Ready"}:item))).catch(err=>{setFiles(items=>items.map(item=>item.id===id?{...item,status:"Failed · try again"}:item));throw err}).finally(()=>pendingUploads.current.delete(id));pendingUploads.current.set(id,pending)});setFiles(current=>[...current,...next]);if(input.current)input.current.value=""};
  const start=async()=>{if(!files.length){setError("Choose at least one supported file.");return}setUploading(true);setError("");const saves=await Promise.allSettled(Array.from(pendingUploads.current.values()));if(saves.some(result=>result.status==="rejected")){setUploading(false);setError("One or more files could not be saved. Your earlier files are still present; remove or retry only the failed files.");return}let p=0;const timer=window.setInterval(()=>{if(pauseRef.current)return;p+=10;setFiles(fs=>fs.map(f=>({...f,progress:Math.min(100,p),status:p>=100?"Uploaded · quality checked":"Uploading"})));if(p>=100){clearInterval(timer);setUploading(false);window.setTimeout(()=>{const names=files.map(f=>f.name).join(" ").toLowerCase();const economics=/econom|micro|macro|demand|supply|gdp/.test(names);update(assessment.id,{files:files.map(f=>({...f,progress:100,status:"OCR complete",preview:undefined})),stage:"uploaded",title:economics?"Economics question paper & answer sheets":assessment.title,subject:economics?"Economics":assessment.subject,totalReviews:Math.max(assessment.totalReviews,files.length*4)});done()},350)}},180)};
  const pause=()=>{pauseRef.current=!pauseRef.current;setPaused(pauseRef.current);setFiles(fs=>fs.map(f=>({...f,status:pauseRef.current?"Paused":"Uploading"})))};
  return <><DialogHead eyebrow={assessment.title} title="Upload and classify evidence"/><p className="modal-copy">The document roles below determine how grading, learning-gap analysis, study guides and worksheets use each file.</p><div className="dropzone" role="button" tabIndex={0} onClick={()=>input.current?.click()} onKeyDown={e=>(e.key==="Enter"||e.key===" ")&&input.current?.click()} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();add(e.dataTransfer.files)}}><span>↑</span><b>Drop scanned handwriting or digital files</b><small>PDF, Word, Markdown, text, spreadsheet or image · multiple files · 10 MB each</small><button type="button" className="secondary" onClick={e=>{e.stopPropagation();input.current?.click()}}>Browse / Choose File</button><input ref={input} className="file-input" type="file" multiple accept={DOCUMENT_ACCEPT} onChange={e=>e.target.files&&add(e.target.files)}/></div>{error&&<p className="form-error" role="alert">{error}</p>}<div className="upload-list evidence-upload-list">{files.map(f=><div key={f.id}>{f.preview?<img src={f.preview} alt={`Preview ${f.name}`}/>:<span className="file-icon">{f.name.split(".").pop()?.toUpperCase()}</span>}<div><b>{f.name}</b><small>{(f.size/1024/1024).toFixed(2)} MB · {f.status}</small><select aria-label={`Document role for ${f.name}`} value={f.documentRole||inferDocumentRole(f.name)} onChange={e=>setFiles(items=>items.map(item=>item.id===f.id?{...item,documentRole:e.target.value as DocumentRole}:item))}>{roles.map(role=><option key={role}>{role}</option>)}</select><Progress value={f.progress}/></div><button disabled={uploading} onClick={()=>setFiles(x=>x.filter(v=>v.id!==f.id))} aria-label={`Remove ${f.name}`}>×</button></div>)}</div><div className="button-row">{uploading&&<button className="secondary" onClick={pause}>{paused?"Resume":"Pause"}</button>}<button className="secondary" disabled={uploading} onClick={()=>setFiles(fs=>fs.map(f=>f.status.includes("Failed")?{...f,status:"Ready",progress:0}:f))}>Retry failed</button><button className="primary" disabled={uploading} onClick={start}>Save evidence & start OCR</button></div></>
}
